@echo off
setlocal
cd /d "%~dp0"
title Ultimate PC Copilot - Preflight and Build

echo.
echo ============================================
echo   Ultimate PC Copilot - Source Preflight
echo ============================================
echo.

findstr /C:"using System.Collections;" UltimatePCCopilot.cs >nul
if errorlevel 1 (
  echo FAILED: System.Collections import is missing.
  pause
  exit /b 1
)

findstr /C:"var s=CardPanel" UltimatePCCopilot.cs >nul
if not errorlevel 1 (
  echo FAILED: Old Dashboard variable conflict is still present.
  pause
  exit /b 1
)

findstr /C:"public static void Main()" UltimatePCCopilot.cs >nul
if errorlevel 1 (
  echo FAILED: Application entry point is missing.
  pause
  exit /b 1
)

findstr /C:"TextMain=Color.FromArgb" UltimatePCCopilot.cs >nul
if errorlevel 1 (
  echo FAILED: UI color rename is missing.
  pause
  exit /b 1
)

findstr /C:"async Task RunStages" UltimatePCCopilot.cs >nul
if errorlevel 1 (
  echo FAILED: Staged progress engine is missing.
  pause
  exit /b 1
)

findstr /C:"progressStage" UltimatePCCopilot.cs >nul
if errorlevel 1 (
  echo FAILED: Progress status UI is missing.
  pause
  exit /b 1
)


findstr /C:"Width=1130" UltimatePCCopilot.cs >nul
if errorlevel 1 (
  echo FAILED: Stable wide workspace is missing.
  pause
  exit /b 1
)

findstr /C:"var progTop=new Panel" UltimatePCCopilot.cs >nul
if errorlevel 1 (
  echo FAILED: Top progress panel is missing.
  pause
  exit /b 1
)

findstr /C:"mainHost=new Panel" UltimatePCCopilot.cs >nul
if not errorlevel 1 (
  echo FAILED: Broken v4 nested workspace code is still present.
  pause
  exit /b 1
)

findstr /C:"ShowDetailedScan" UltimatePCCopilot.cs >nul
if errorlevel 1 (
  echo FAILED: Detailed scan screen is missing.
  pause
  exit /b 1
)

findstr /C:"AI double-check" UltimatePCCopilot.cs >nul
if errorlevel 1 (
  echo FAILED: Startup AI double-check is missing.
  pause
  exit /b 1
)

findstr /C:"Estimated stage progress" UltimatePCCopilot.cs >nul
if errorlevel 1 (
  echo FAILED: Estimated scan progress UI is missing.
  pause
  exit /b 1
)


findstr /C:"LIVE COVERAGE FEED" UltimatePCCopilot.cs >nul
if errorlevel 1 (
  echo FAILED: Live scan coverage feed is missing.
  pause
  exit /b 1
)

findstr /C:"Taking longer than usual" UltimatePCCopilot.cs >nul
if errorlevel 1 (
  echo FAILED: ETA overrun fix is missing.
  pause
  exit /b 1
)

findstr /C:"ConcurrentQueue" UltimatePCCopilot.cs >nul
if errorlevel 1 (
  echo FAILED: File coverage queue is missing.
  pause
  exit /b 1
)


findstr /C:"Heartbeat:" UltimatePCCopilot.cs >nul
if errorlevel 1 (
  echo FAILED: Scan heartbeat is missing.
  pause
  exit /b 1
)

findstr /C:"Watchdog:" UltimatePCCopilot.cs >nul
if errorlevel 1 (
  echo FAILED: Scan watchdog is missing.
  pause
  exit /b 1
)

findstr /C:"Return to app" UltimatePCCopilot.cs >nul
if errorlevel 1 (
  echo FAILED: Safe return button is missing.
  pause
  exit /b 1
)


findstr /C:"What's taking so long?" UltimatePCCopilot.cs >nul
if errorlevel 1 (
  echo FAILED: Slow-scan diagnostic button is missing.
  pause
  exit /b 1
)

findstr /C:"DiagnoseSlowScan" UltimatePCCopilot.cs >nul
if errorlevel 1 (
  echo FAILED: Slow-scan diagnostics are missing.
  pause
  exit /b 1
)

findstr /C:"ApplyScanFix" UltimatePCCopilot.cs >nul
if errorlevel 1 (
  echo FAILED: Safe scan recovery engine is missing.
  pause
  exit /b 1
)


findstr /C:"Scan state must exist before any button/event handler can reference it." UltimatePCCopilot.cs >nul
if errorlevel 1 (
  echo FAILED: Scan-state declaration ordering fix is missing.
  pause
  exit /b 1
)


findstr /C:"Check for app update" UltimatePCCopilot.cs >nul
if errorlevel 1 (
  echo FAILED: App updater UI is missing.
  pause
  exit /b 1
)

findstr /C:"Sha256File" UltimatePCCopilot.cs >nul
if errorlevel 1 (
  echo FAILED: Update verification is missing.
  pause
  exit /b 1
)

findstr /C:"AutoUpdateCheckIfDue" UltimatePCCopilot.cs >nul
if errorlevel 1 (
  echo FAILED: Automatic update check is missing.
  pause
  exit /b 1
)


findstr /C:"using System.Threading;" UltimatePCCopilot.cs >nul
if not errorlevel 1 (
  echo FAILED: System.Threading import would make Timer ambiguous.
  pause
  exit /b 1
)

findstr /C:"System.Windows.Forms.Timer" UltimatePCCopilot.cs >nul
if errorlevel 1 (
  echo FAILED: WinForms Timer qualification is missing.
  pause
  exit /b 1
)


findstr /C:"Startup Intelligence" UltimatePCCopilot.cs >nul
if errorlevel 1 (
  echo FAILED: Intelligent Startup page is missing.
  pause
  exit /b 1
)

findstr /C:"AI double-check" UltimatePCCopilot.cs >nul
if errorlevel 1 (
  echo FAILED: Startup AI double-check feature is missing.
  pause
  exit /b 1
)

findstr /C:"DisableStartupItem" UltimatePCCopilot.cs >nul
if errorlevel 1 (
  echo FAILED: Startup disable safety engine is missing.
  pause
  exit /b 1
)


findstr /C:"System.IO.Compression.FileSystem.dll" BUILD-APP.bat >nul
if errorlevel 1 (
  echo FAILED: ZipFile compiler reference is missing.
  pause
  exit /b 1
)

echo Preflight checks passed.
echo Starting Windows compiler...
echo.
call BUILD-APP.bat
