ULTIMATE PC COPILOT
===================

WHAT THIS BUILD IS
------------------
A Windows desktop control center combining:
- CCleaner-style safe cleanup/analyze
- Microsoft Defender malware scans and threat history
- Live tray monitoring
- Windows repair tools with approval warnings
- startup and storage inspection
- game optimizer that preserves Discord/audio/network/security
- global Ctrl+Shift+Space Copilot overlay
- on-demand screenshot + AI help for games, schoolwork, apps, and PC problems
- deep diagnostic reports
- optional real-time web lookup through the OpenAI API
- local adaptive memory notes that you explicitly choose to save

BUILD
-----
1. Extract this ZIP completely.
2. Double-click CHECK-AND-BUILD.bat. (Recommended)
   You can also use BUILD-APP.bat directly.
3. It creates UltimatePCCopilot.exe.
4. Right-click UltimatePCCopilot.exe -> Run as administrator.

GLOBAL COPILOT HOTKEY
---------------------
Ctrl + Shift + Space

From a game or any app, press the hotkey.
- Ask: uses your text and active-window name.
- Screenshot + Ask: takes ONE screenshot when you click it, then sends that image
  with your question to the configured OpenAI API.

The app does NOT continuously upload your screen.

AI SETUP
--------
Open Settings inside the app and enter an OpenAI API key.
API usage is separate from a ChatGPT subscription.

The default model field is editable because model availability can change.
If your account does not support the default model, put a currently supported
vision-capable Responses API model in Settings.

WEB LOOKUP
----------
When "Current web" is checked, the app requests OpenAI's web-search tool.
Availability depends on the API model/account. If unsupported, turn the box off.

LIVE MALWARE PROTECTION
-----------------------
This app deliberately does NOT invent its own kernel antivirus driver.
Microsoft Defender performs actual real-time file/process/behavior malware protection.
PC Copilot:
- checks Defender status
- updates signatures
- runs quick/full/offline scans
- watches for new Defender detections
- audits exclusions/startup/scheduled-task/security settings
- explains findings

GAME OPTIMIZER
--------------
Designed to preserve:
- Discord and screen sharing
- Windows audio
- network access
- Microsoft Defender
- GPU software/drivers
- anti-cheat and the running game

It avoids aggressive "FPS tweak" service killing that can make systems unstable.

PRIVACY / MEMORY
----------------
Adaptive memory in this build is LOCAL and explicit.
It remembers only notes you press "Remember this" on.
It does NOT automatically read your ChatGPT memory or chat history.

DATA
----
%LOCALAPPDATA%\UltimatePCCopilot

IMPORTANT
---------
This is a custom utility, not an official Microsoft, OpenAI, Malwarebytes, or CCleaner product.
Back up important files normally; repair tools are not a replacement for backups.
