@echo off
setlocal
cd /d "%~dp0"
title Build Ultimate PC Copilot
echo.
echo Building Ultimate PC Copilot...
echo.

set CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe
if not exist "%CSC%" set CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe

if not exist "%CSC%" (
  echo Microsoft .NET Framework C# compiler was not found.
  echo Install/enable .NET Framework 4.x and run this again.
  pause
  exit /b 1
)

"%CSC%" /nologo /target:winexe /platform:anycpu /optimize+ ^
 /reference:System.dll ^
 /reference:System.Core.dll ^
 /reference:System.Drawing.dll ^
 /reference:System.Windows.Forms.dll ^
 /reference:System.Management.dll ^
 /reference:System.Web.Extensions.dll ^
 /reference:System.Configuration.dll ^
 /reference:System.IO.Compression.dll ^
 /reference:System.IO.Compression.FileSystem.dll ^
 /out:UltimatePCCopilot.exe UltimatePCCopilot.cs

if errorlevel 1 (
  echo.
  echo BUILD FAILED. Copy or photograph the errors above and send them to ChatGPT.
  pause
  exit /b 1
)

echo.
echo BUILD SUCCESSFUL.
echo Created UltimatePCCopilot.exe
echo.
echo Right-click UltimatePCCopilot.exe and choose "Run as administrator"
echo for full repair/security functionality.
pause
