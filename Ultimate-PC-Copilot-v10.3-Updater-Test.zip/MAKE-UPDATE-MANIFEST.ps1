param(
    [Parameter(Mandatory=$true)][string]$PackagePath,
    [Parameter(Mandatory=$true)][string]$PackageUrl,
    [Parameter(Mandatory=$true)][string]$Version,
    [string]$Notes=""
)
$hash=(Get-FileHash -Algorithm SHA256 -Path $PackagePath).Hash.ToLower()
$obj=[ordered]@{
    version=$Version
    channel="Stable"
    packageUrl=$PackageUrl
    sha256=$hash
    notes=$Notes
}
$obj | ConvertTo-Json | Set-Content -Encoding UTF8 "update.json"
Write-Host "Created update.json"
Write-Host "SHA256: $hash"
