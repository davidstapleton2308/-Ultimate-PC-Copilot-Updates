
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Management;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Microsoft.Win32;

namespace UltimatePCCopilot
{
    public class AppSettings
    {
        public string ApiKey = "";
        public string Model = "gpt-4.1-mini";
        public bool UseWeb = true;
        public bool LiveGuard = true;
        public bool CaptureOnlyWhenAsked = true;
        public bool GameModeAuto = true;
        public bool AutoInstallUpdates = false;
        public string UpdateManifestUrl = "https://raw.githubusercontent.com/davidstapleton2308/-Ultimate-PC-Copilot-Updates/main/update.json";
        public DateTime LastUpdateCheck = DateTime.MinValue;
        public List<string> Memory = new List<string>();
    }

    public class StartupRow
    {
        public string Name{get;set;}
        public string Publisher{get;set;}
        public string Impact{get;set;}
        public string Recommendation{get;set;}
        public string Explanation{get;set;}
        public string Command{get;set;}
        public string Location{get;set;}
        public string User{get;set;}
    }


    public class UpdateManifest
    {
        public string version {get;set;}
        public string packageUrl {get;set;}
        public string sha256 {get;set;}
        public string notes {get;set;}
        public string channel {get;set;}
    }

    public class MainForm : Form
    {
        public const string AppVersion = "0.10.3";
        public const string UpdateChannelName = "Stable";

        [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr hWnd,int id,uint fsModifiers,uint vk);
        [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr hWnd,int id);
        [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr hWnd,StringBuilder text,int count);
        const int WM_HOTKEY=0x0312, HOTKEY_ID=9917;
        const uint MOD_CONTROL=0x0002, MOD_SHIFT=0x0004;
        const uint VK_SPACE=0x20;

        readonly Color Bg=Color.FromArgb(9,14,27), Side=Color.FromArgb(12,20,36),
            Card=Color.FromArgb(17,26,45), Card2=Color.FromArgb(23,35,58),
            TextMain=Color.FromArgb(244,247,252), Muted=Color.FromArgb(148,163,184),
            Indigo=Color.FromArgb(99,102,241), Blue=Color.FromArgb(59,130,246),
            Teal=Color.FromArgb(20,184,166), Green=Color.FromArgb(34,197,94),
            Amber=Color.FromArgb(245,158,11), Red=Color.FromArgb(239,68,68);

        string dataDir, reportsDir, settingsFile, logFile;
        AppSettings settings;
        Panel content, sidebar;
        Label pageTitle, pageSub, headerStatus;
        ProgressBar progress;
        Label progressStage, progressDetail, progressElapsed;
        RichTextBox log;
        Stopwatch operationWatch=new Stopwatch();
        System.Windows.Forms.Timer operationTimer=new System.Windows.Forms.Timer();
        NotifyIcon tray;
        System.Windows.Forms.Timer liveTimer=new System.Windows.Forms.Timer(), threatTimer=new System.Windows.Forms.Timer();
        Dictionary<string,Button> nav=new Dictionary<string,Button>();
        PerformanceCounter cpuCounter;
        float cpuNow=0; int ramNow=0; string activeApp="—";
        DateTime lastThreat=DateTime.MinValue, lastHighCpu=DateTime.MinValue;

        public MainForm()
        {
            dataDir=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"UltimatePCCopilot");
            reportsDir=Path.Combine(dataDir,"Reports");
            Directory.CreateDirectory(dataDir); Directory.CreateDirectory(reportsDir);
            settingsFile=Path.Combine(dataDir,"settings.json");
            logFile=Path.Combine(dataDir,"activity.log");
            settings=LoadSettings();

            Text="Ultimate PC Copilot";
            StartPosition=FormStartPosition.CenterScreen;
            Size=new Size(1400,860);
            MinimumSize=new Size(1160,720);
            BackColor=Bg; ForeColor=TextMain; Font=new Font("Segoe UI",9.5f);
            Icon=SystemIcons.Shield;

            BuildShell();
            SetupTray();
            SetupMonitoring();
            Shown += async (s,e)=>{
                EnableModernTls();
                RegisterHotKey(Handle,HOTKEY_ID,MOD_CONTROL|MOD_SHIFT,VK_SPACE);
                await AutoUpdateCheckIfDue();
            };
            FormClosed += (s,e)=>{ UnregisterHotKey(Handle,HOTKEY_ID); tray.Visible=false; };
            ShowPage("Dashboard");
            WriteLog("Ultimate PC Copilot started.");
        }

        protected override void WndProc(ref Message m)
        {
            if(m.Msg==WM_HOTKEY && m.WParam.ToInt32()==HOTKEY_ID) ShowOverlay();
            base.WndProc(ref m);
        }

        AppSettings LoadSettings()
        {
            try{
                if(File.Exists(settingsFile)){
                    var js=new JavaScriptSerializer();
                    return js.Deserialize<AppSettings>(File.ReadAllText(settingsFile)) ?? new AppSettings();
                }
            }catch{}
            return new AppSettings();
        }
        void SaveSettings(){try{File.WriteAllText(settingsFile,new JavaScriptSerializer().Serialize(settings));}catch{}}

        void BuildShell()
        {
            sidebar=new Panel{Dock=DockStyle.Left,Width=215,BackColor=Side}; Controls.Add(sidebar);
            var brand=new Label{Text="ULTIMATE\nPC COPILOT",Left=18,Top=18,Width=180,Height=56,ForeColor=TextMain,Font=new Font("Segoe UI Semibold",16,FontStyle.Bold)};
            var small=new Label{Text="AI • SECURITY • PERFORMANCE",Left=18,Top=78,Width=180,Height=24,ForeColor=Color.FromArgb(165,180,252),Font=new Font("Segoe UI Semibold",8)};
            sidebar.Controls.Add(brand);sidebar.Controls.Add(small);
            string[] pages={"Dashboard","AI Copilot","Game Mode","Cleaner","Security","Live Guard","Repair","Startup","Storage","Updates","Reports","Settings"};
            int y=112;
            foreach(var p in pages){
                var b=new Button{Text=p,Tag=p,Left=12,Top=y,Width=190,Height=35,FlatStyle=FlatStyle.Flat,BackColor=Side,ForeColor=Muted,TextAlign=ContentAlignment.MiddleLeft,Padding=new Padding(12,0,0,0),Cursor=Cursors.Hand};
                b.FlatAppearance.BorderSize=0;b.Click+=(s,e)=>ShowPage((string)((Button)s).Tag);
                sidebar.Controls.Add(b);nav[p]=b;y+=38;
            }
            var hot=new Label{Text="Ctrl + Shift + Space\nopens Copilot anywhere",Left=18,Top=710,Width=180,Height=42,ForeColor=Muted,Anchor=AnchorStyles.Left|AnchorStyles.Bottom};
            sidebar.Controls.Add(hot);

            var header=new Panel{Dock=DockStyle.Top,Height=80,BackColor=Bg}; Controls.Add(header); header.BringToFront();
            pageTitle=new Label{Text="Dashboard",Left=28,Top=13,AutoSize=true,ForeColor=TextMain,Font=new Font("Segoe UI Semibold",22,FontStyle.Bold)};
            pageSub=new Label{Text="Your PC, explained.",Left=30,Top=49,AutoSize=true,ForeColor=Muted};
            headerStatus=new Label{Text="● Ready",AutoSize=true,ForeColor=Green,Top=27,Anchor=AnchorStyles.Top|AnchorStyles.Right};
            header.Controls.Add(pageTitle);header.Controls.Add(pageSub);header.Controls.Add(headerStatus);
            header.Resize+=(s,e)=>headerStatus.Left=header.Width-headerStatus.Width-28;

            // Progress lives directly under the title, but uses the same proven
            // top-level docking architecture as the working v3 build.
            var progTop=new Panel{
                Dock=DockStyle.Top,
                Height=76,
                BackColor=Color.FromArgb(12,20,36),
                Padding=new Padding(28,8,28,8)
            };
            Controls.Add(progTop);
            progTop.BringToFront();

            progressStage=new Label{
                Text="Ready",
                Left=28,Top=8,Width=560,Height=22,
                ForeColor=TextMain,
                Font=new Font("Segoe UI Semibold",9.8f,FontStyle.Bold)
            };
            progressDetail=new Label{
                Text="Nothing running right now.",
                Left=28,Top=31,Width=760,Height=20,
                ForeColor=Muted
            };
            progressElapsed=new Label{
                Text="",
                Top=8,Width=170,Height=22,
                ForeColor=Muted,
                TextAlign=ContentAlignment.MiddleRight,
                Anchor=AnchorStyles.Top|AnchorStyles.Right
            };
            progress=new ProgressBar{
                Left=28,Top=57,Height=7,
                Minimum=0,Maximum=100,Value=0,
                Style=ProgressBarStyle.Blocks,
                Anchor=AnchorStyles.Left|AnchorStyles.Top|AnchorStyles.Right
            };

            progTop.Controls.Add(progressStage);
            progTop.Controls.Add(progressDetail);
            progTop.Controls.Add(progressElapsed);
            progTop.Controls.Add(progress);

            progTop.Resize+=(s,e)=>{
                progressElapsed.Left=progTop.Width-progressElapsed.Width-28;
                progress.Width=Math.Max(300,progTop.Width-56);
                progressDetail.Width=Math.Max(380,progTop.Width-260);
            };

            // Keep the detailed log as a compact footer.
            var bottom=new Panel{
                Dock=DockStyle.Bottom,
                Height=86,
                BackColor=Side,
                Padding=new Padding(16,7,16,7)
            };
            Controls.Add(bottom);
            bottom.BringToFront();

            log=new RichTextBox{
                Dock=DockStyle.Fill,
                BackColor=Side,
                ForeColor=Color.FromArgb(203,213,225),
                BorderStyle=BorderStyle.None,
                ReadOnly=true,
                Font=new Font("Consolas",8.3f)
            };
            bottom.Controls.Add(log);

            // Main content remains the exact reliable v3 approach: one Fill panel.
            content=new Panel{
                Dock=DockStyle.Fill,
                BackColor=Bg,
                AutoScroll=true,
                Padding=new Padding(26,12,26,22)
            };
            Controls.Add(content);
            content.BringToFront();
        }

        // Wider fixed workspace. No dynamic parent/child resizing logic:
        // this is intentionally boring because boring is reliable in WinForms.
        FlowLayoutPanel Root(){var r=new FlowLayoutPanel{Dock=DockStyle.Top,AutoSize=true,WrapContents=false,FlowDirection=FlowDirection.TopDown,Width=1130};content.Controls.Add(r);return r;}
        Panel CardPanel(int h=150){var p=new Panel{Width=1100,Height=h,BackColor=Card,Margin=new Padding(0,0,0,14),Padding=new Padding(18)};return p;}
        Label H(string t,int sz=15){return new Label{Text=t,AutoSize=true,ForeColor=TextMain,Font=new Font("Segoe UI Semibold",sz,FontStyle.Bold)};}
        Label D(string t,int w=680,int h=46){return new Label{Text=t,ForeColor=Muted,Width=w,Height=h};}
        Button Btn(string t,Color c,int w=170){var b=new Button{Text=t,Width=w,Height=40,BackColor=c,ForeColor=Color.White,FlatStyle=FlatStyle.Flat,Cursor=Cursors.Hand,Font=new Font("Segoe UI Semibold",9.3f)};b.FlatAppearance.BorderSize=0;return b;}
        void Add(Panel p,Control c,int x,int y){c.Left=x;c.Top=y;p.Controls.Add(c);}
        bool Ask(string title,string body){return MessageBox.Show(body,title,MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes;}
        void Info(string title,string body){MessageBox.Show(body,title,MessageBoxButtons.OK,MessageBoxIcon.Information);}

        void ShowPage(string p)
        {
            foreach(var kv in nav){bool a=kv.Key==p;kv.Value.BackColor=a?Color.FromArgb(27,40,62):Side;kv.Value.ForeColor=a?TextMain:Muted;}
            content.Controls.Clear();pageTitle.Text=p;
            if(p=="Dashboard") Dashboard();
            else if(p=="AI Copilot") AICopilot();
            else if(p=="Game Mode") GameMode();
            else if(p=="Cleaner") Cleaner();
            else if(p=="Security") Security();
            else if(p=="Live Guard") LiveGuard();
            else if(p=="Repair") Repair();
            else if(p=="Startup") Startup();
            else if(p=="Storage") Storage();
            else if(p=="Updates") Updates();
            else if(p=="Reports") Reports();
            else SettingsPage();
        }

        void Dashboard()
        {
            pageSub.Text="Live health, security, and one-click help";
            var r=Root();
            var statusCard=CardPanel(125);Add(statusCard,H("Live system"),18,15);
            Add(statusCard,D("CPU "+cpuNow.ToString("0")+"%     RAM "+ramNow+"%     Active app: "+activeApp,800,28),18,50);
            Add(statusCard,D("Live Guard: "+(settings.LiveGuard?"watching":"paused")+"     Defender real-time: "+DefenderRT(),800,28),18,80);r.Controls.Add(statusCard);

            var hero=CardPanel(210);Add(hero,H("Ask what is wrong"),18,16);
            Add(hero,D("Describe the symptom. PC Copilot will collect relevant Windows evidence and explain the likely causes in normal English.",760,40),18,50);
            var box=new TextBox{Width=620,Height=34,BackColor=Color.FromArgb(8,15,27),ForeColor=TextMain,BorderStyle=BorderStyle.FixedSingle,Font=new Font("Segoe UI",10)};
            Add(hero,box,18,102);
            var go=Btn("Diagnose with AI",Indigo,180);Add(hero,go,655,100);
            go.Click+=async(s,e)=>{if(box.Text.Trim().Length<3){Info("Describe it first","Type what is happening.");return;}BeginOperation("Taking your PC's vitals…","Collecting the clues that matter for your symptom.",15);await Diagnose(box.Text.Trim(),false);CompleteOperation("AI diagnosis ready");};
            var now=Btn("Why is PC busy now?",Card2,180);Add(hero,now,655,148);now.Click+=async(s,e)=>{BeginOperation("Catching your PC in the act…","Looking at CPU, RAM, active apps and recent Windows errors.",15);await Diagnose("Explain why my PC is busy right now and whether anything is abnormal.",false);CompleteOperation("Live diagnosis ready");};
            r.Controls.Add(hero);

            var hot=CardPanel(155);Add(hot,H("Instant Copilot overlay"),18,16);
            Add(hot,D("Press Ctrl + Shift + Space from a game, browser, assignment, or any app. It can capture the current screen only when you ask and answer what to do next.",720,50),18,50);
            var test=Btn("Test overlay",Blue,160);Add(hot,test,18,105);test.Click+=(s,e)=>ShowOverlay();r.Controls.Add(hot);
        }

        void AICopilot()
        {
            pageSub.Text="Ask about your PC, your screen, school, games, or current task";
            var r=Root();
            var p=CardPanel(360);Add(p,H("AI Copilot"),18,15);
            Add(p,D("This assistant can use a diagnostic snapshot, an on-demand screenshot, local preferences you chose to remember, and optional current web lookup.",820,42),18,47);
            var q=new TextBox{Left=18,Top=100,Width=690,Height=36,BackColor=Color.FromArgb(8,15,27),ForeColor=TextMain,BorderStyle=BorderStyle.FixedSingle,Font=new Font("Segoe UI",10)};p.Controls.Add(q);
            var ask=Btn("Ask",Indigo,120);Add(p,ask,725,98);
            var shot=Btn("Ask + screenshot",Teal,160);Add(p,shot,18,150);
            var diag=Btn("Ask + PC diagnostics",Blue,190);Add(p,diag,190,150);
            var web=new CheckBox{Text="Allow current web lookup",Checked=settings.UseWeb,ForeColor=TextMain,AutoSize=true,Left=405,Top=161};p.Controls.Add(web);
            var answer=new RichTextBox{Left=18,Top=205,Width=980,Height=125,BackColor=Color.FromArgb(8,15,27),ForeColor=TextMain,ReadOnly=true,BorderStyle=BorderStyle.None};p.Controls.Add(answer);
            ask.Click+=async(s,e)=>answer.Text=await AskAI(q.Text,false,false,web.Checked);
            shot.Click+=async(s,e)=>answer.Text=await AskAI(q.Text,true,false,web.Checked);
            diag.Click+=async(s,e)=>answer.Text=await AskAI(q.Text,false,true,web.Checked);
            r.Controls.Add(p);

            var mem=CardPanel(180);Add(mem,H("Adaptive memory"),18,15);
            Add(mem,D("PC Copilot keeps only the preferences/notes you explicitly save inside this app. It does not automatically read your ChatGPT history. You can edit or erase this memory anytime.",800,42),18,48);
            var m=new TextBox{Left=18,Top=100,Width=620,Height=34,BackColor=Color.FromArgb(8,15,27),ForeColor=TextMain,BorderStyle=BorderStyle.FixedSingle};mem.Controls.Add(m);
            var save=Btn("Remember this",Card2,150);Add(mem,save,655,98);
            save.Click+=(s,e)=>{if(m.Text.Trim().Length>0){settings.Memory.Add(m.Text.Trim());SaveSettings();WriteLog("Saved a Copilot memory note.");m.Clear();Info("Saved","I will include that note in future AI requests from this app.");}};
            r.Controls.Add(mem);
        }

        void GameMode()
        {
            pageSub.Text="Performance mode that keeps Discord and your game usable";
            var r=Root();
            var p=CardPanel(215);Add(p,H("Game Optimizer"),18,15);
            Add(p,D("Safe optimization focuses on reducing avoidable background load without killing Discord, your browser, Windows Audio, GPU software, anti-cheat, or Defender.",810,52),18,48);
            var on=Btn("Optimize for current game",Indigo,210);Add(p,on,18,115);
            var restore=Btn("Restore balanced mode",Card2,190);Add(p,restore,245,115);
            on.Click+=async(s,e)=>await OptimizeForGame();
            restore.Click+=async(s,e)=>await RunWork("Restoring Balanced power mode...","Balanced mode restored.",()=>RunPS("powercfg /setactive SCHEME_BALANCED"));
            var disc=new Label{Text="Discord / screen share: preserved",ForeColor=Green,Left=18,Top=168,Width=260,Height=24};p.Controls.Add(disc);r.Controls.Add(p);

            var p2=CardPanel(175);Add(p2,H("In-game Copilot"),18,15);
            Add(p2,D("Ctrl + Shift + Space opens a compact overlay above the game. Choose Screenshot + Ask when you are stuck; it captures the current display once and sends it with your question.",810,50),18,50);
            var t=Btn("Open overlay now",Teal,170);Add(p2,t,18,115);t.Click+=(s,e)=>ShowOverlay();r.Controls.Add(p2);

            var caution=CardPanel(145);Add(caution,H("What optimizer will not do"),18,15);
            Add(caution,D("It will not disable Defender, anti-cheat, Windows Audio, Discord, GPU drivers, networking, or randomly kill services. Those 'ultimate FPS tweak' tricks often create instability for tiny or imaginary gains.",850,65),18,50);r.Controls.Add(caution);
        }

        async Task OptimizeForGame()
        {
            string app=ForegroundTitle();
            if(!Ask("Optimize game mode","PC Copilot will switch Windows to High Performance, clear stale temp cache, and reduce a few nonessential UI/background behaviors. It will preserve Discord, audio, network, Defender, GPU software and your running game.\n\nActive window: "+app+"\n\nContinue?"))return;
            await RunStages(
                "Game optimizer",
                "Game optimization applied",
                new string[]{"Switching Windows to High Performance","Refreshing the network resolver","Clearing safe temporary clutter","Confirming Discord, audio and security stay untouched"},
                new Action[]{
                    ()=>RunPS("powercfg /setactive SCHEME_MIN"),
                    ()=>RunPS("ipconfig /flushdns"),
                    ()=>{try{SafeDelete(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Temp"));}catch{}},
                    ()=>WriteLog("Game optimizer preserved Discord/security/audio/network processes by design.")
                }
            );
        }

        void Cleaner()
        {
            pageSub.Text="Analyze first, then clean only safe categories";
            var r=Root();var p=CardPanel(260);Add(p,H("Smart Cleaner"),18,15);
            Add(p,D("Cleans temp/cache/crash data. It does not delete Downloads, Documents, passwords, cookies, or browser history.",820,42),18,48);
            var outp=new RichTextBox{Left=18,Top=92,Width=610,Height=125,BackColor=Color.FromArgb(8,15,27),ForeColor=TextMain,ReadOnly=true,BorderStyle=BorderStyle.None};p.Controls.Add(outp);
            var a=Btn("Analyze",Blue,150);Add(p,a,655,93);var c=Btn("Clean safe junk",Teal,150);Add(p,c,655,142);
            a.Click+=async(s,e)=>{await RunWork("Analyzing disposable files...","Analysis complete.",()=>{});outp.Text=CleanupAnalysis();};
            c.Click+=async(s,e)=>{if(!Ask("Approve safe cleanup","Delete temporary files, crash dumps and browser cache? Your personal files, passwords, cookies and history are not touched."))return;await RunWork("Cleaning safe junk...","Cleanup finished.",SafeCleanup);outp.Text=CleanupAnalysis();};
            r.Controls.Add(p);
        }

        void Security()
        {
            pageSub.Text="Microsoft Defender-powered security plus clearer explanations";
            var r=Root();var p=CardPanel(235);Add(p,H("Malware scanner"),18,15);
            Add(p,D("Uses Microsoft's real antivirus engine and current signatures. PC Copilot adds progress phases, threat summaries, exclusion checks and plain-English advice.",820,48),18,47);
            var q=Btn("Quick scan",Teal,145);Add(p,q,18,112);var f=Btn("Full scan",Indigo,145);Add(p,f,175,112);var hist=Btn("Threat history",Card2,155);Add(p,hist,332,112);var off=Btn("Offline scan",Red,155);Add(p,off,499,112);
            q.Click+=async(s,e)=>await ShowDetailedScan(
                "Quick Malware Scan",
                "A fast security check of the places malware most commonly tries to hide.",
                new string[]{"Updating Defender security intelligence","Scanning common malware locations","Reviewing Defender threat history","Building your plain-English security report"},
                new int[]{20,180,15,8},
                new Action[]{()=>DefenderUpdate(),()=>RunPS("Start-MpScan -ScanType QuickScan"),()=>RunPS("Get-MpThreatDetection | Select -First 30 | Out-String"),()=>WriteLog("Preparing quick-scan explanation.")},
                ()=>BuildDefenderSummary("Quick malware scan")
            );
            f.Click+=async(s,e)=>{
                if(Ask("Full scan","This scans the entire PC and can temporarily increase fan/CPU/disk use. Start?"))
                    await ShowDetailedScan(
                        "Full Malware Scan",
                        "The deep clean-room treatment: Defender checks the whole PC, then PC Copilot explains what matters.",
                        new string[]{"Updating Defender security intelligence","Scanning the entire PC for malware","Reviewing anything Defender detected","Confirming protection is healthy","Building your plain-English security report"},
                        new int[]{20,1200,20,10,8},
                        new Action[]{()=>DefenderUpdate(),()=>RunPS("Start-MpScan -ScanType FullScan"),()=>RunPS("Get-MpThreatDetection | Select -First 50 | Out-String"),()=>RunPS("Get-MpComputerStatus | Out-String"),()=>WriteLog("Preparing full-scan explanation.")},
                        ()=>BuildDefenderSummary("Full malware scan")
                    );
            };
            hist.Click+=(s,e)=>ShowThreatHistory();
            off.Click+=(s,e)=>{if(Ask("Offline malware scan","This restarts your PC and scans before normal Windows fully loads. Save your work first. Start?"))RunPS("Start-MpWDOScan");};
            var audit=Btn("Deep security audit",Blue,190);Add(p,audit,18,170);audit.Click+=async(s,e)=>await ShowDetailedScan(
                "Deep Security Audit",
                "A broader check for weak protection, odd startup behavior, suspicious persistence, exclusions, proxy changes, and recent detections.",
                new string[]{"Checking Defender protection and exclusions","Inspecting startup and scheduled-task persistence","Reviewing proxy and hosts settings","Checking recent Defender detections","Writing the security audit"},
                new int[]{12,18,10,12,8},
                new Action[]{()=>RunPS("Get-MpComputerStatus | Out-String; Get-MpPreference | Select ExclusionPath,ExclusionProcess,ExclusionExtension | Out-String"),()=>RunPS("Get-CimInstance Win32_StartupCommand | Out-String; Get-ScheduledTask | ? {$_.TaskPath -notlike '\\Microsoft\\*'} | Out-String"),()=>RunPS("netsh winhttp show proxy; Get-Content $env:windir\\System32\\drivers\\etc\\hosts"),()=>RunPS("Get-MpThreatDetection | Select -First 50 | Out-String"),()=>SecurityAudit()},
                ()=>"Deep security audit finished. Open Reports for the full technical report. If anything unfamiliar appears in startup, exclusions, scheduled tasks, proxy settings, or threat history, use AI Copilot to explain it before changing anything."
            );
            r.Controls.Add(p);

            var guard=CardPanel(160);Add(guard,H("Always-on protection"),18,15);
            Add(guard,D("Defender remains the actual real-time malware engine. PC Copilot watches Defender health and new detections, explains alerts, and warns if protection is unexpectedly disabled.",820,58),18,50);
            r.Controls.Add(guard);
        }

        void LiveGuard()
        {
            pageSub.Text="Quiet tray monitoring with meaningful alerts";
            var r=Root();var p=CardPanel(190);Add(p,H("Live Guard"),18,15);
            Add(p,D("Watches sustained CPU pressure, memory pressure, low system-drive space, active application, Defender protection state and new Defender detections.",820,50),18,50);
            Add(p,D("Current: CPU "+cpuNow.ToString("0")+"% • RAM "+ramNow+"% • "+activeApp,820,30),18,102);
            var b=Btn(settings.LiveGuard?"Pause guard":"Resume guard",settings.LiveGuard?Amber:Green,170);Add(p,b,18,140);
            b.Click+=(s,e)=>{settings.LiveGuard=!settings.LiveGuard;SaveSettings();ShowPage("Live Guard");};r.Controls.Add(p);
        }

        void Repair()
        {
            pageSub.Text="Repairs explain consequences before approval";
            var r=Root();
            var wr=CardPanel(175);Add(wr,H("Windows integrity repair"),18,14);Add(wr,D("DISM repairs the Windows component image; SFC verifies protected system files; CHKDSK performs an online filesystem scan.",650,42),18,48);
            var ww=D("Before approval: Usually safe, but can take time and use disk/CPU.",650,42);ww.ForeColor=Color.FromArgb(251,191,36);Add(wr,ww,18,98);
            var wb=Btn("Run repair",Blue,190);Add(wr,wb,720,62);
            wb.Click+=async(s,e)=>{
                if(!Ask("Approve Windows integrity repair","DISM repairs the Windows component image; SFC checks protected Windows files; CHKDSK performs an online disk/filesystem scan.\n\nThis can take a while and may make the fans ramp up. Continue?"))return;
                await RunStages(
                    "Windows integrity repair",
                    "Windows repair complete",
                    new string[]{"Repairing the Windows component image with DISM","Checking protected system files with SFC","Scanning the Windows drive with CHKDSK","Wrapping up repair results"},
                    new Action[]{()=>RunPS("DISM /Online /Cleanup-Image /RestoreHealth"),()=>RunPS("sfc /scannow"),()=>RunPS("chkdsk "+Environment.GetEnvironmentVariable("SystemDrive")+" /scan"),()=>CreateDiagnostic("Post-repair health check")}
                );
            };
            r.Controls.Add(wr);
            AddRepair(r,"Network stack reset","Flushes DNS and resets Winsock.","May require a restart. VPN/custom network software may need to reconnect.","Repair network",Teal,()=>{RunPS("ipconfig /flushdns");RunPS("netsh winsock reset");});
            AddRepair(r,"Windows Update cache rebuild","Stops update services and clears downloaded update files, then restarts the services.","Windows may need to redownload pending updates.","Rebuild update cache",Indigo,ResetUpdateCache);
            AddRepair(r,"SSD optimization","Requests Windows TRIM/Optimize on the system drive.","Does not perform a forced old-style defrag on an SSD.","Optimize SSD",Card2,()=>RunPS("Optimize-Volume -DriveLetter "+Environment.GetEnvironmentVariable("SystemDrive").TrimEnd(':')+" -ReTrim -Verbose"));
        }

        void AddRepair(FlowLayoutPanel r,string name,string what,string warning,string bt,Color c,Action act)
        {
            var p=CardPanel(175);Add(p,H(name),18,14);Add(p,D(what,650,42),18,48);
            var w=D("Before approval: "+warning,650,42);w.ForeColor=Color.FromArgb(251,191,36);Add(p,w,18,98);
            var b=Btn(bt,c,190);Add(p,b,720,62);b.Click+=async(s,e)=>{if(!Ask("Approve "+name,what+"\n\n"+warning+"\n\nContinue?"))return;await RunWork("Running "+name.ToLower()+"...",name+" finished.",act);};r.Controls.Add(p);
        }

        void Startup()
        {
            pageSub.Text="Understand what launches with Windows before changing anything";
            var r=Root();

            var p=CardPanel(525);
            Add(p,H("Startup Intelligence"),18,15);
            Add(p,D("PC Copilot explains why each startup item exists, its likely performance impact, whether disabling it is usually safe, and what you could lose.",1010,42),18,48);

            var grid=new DataGridView{
                Left=18,Top=92,Width=1000,Height=285,
                BackgroundColor=Color.FromArgb(8,15,27),
                ForeColor=Color.Black,
                ReadOnly=true,
                AllowUserToAddRows=false,
                SelectionMode=DataGridViewSelectionMode.FullRowSelect,
                MultiSelect=false,
                AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill
            };
            p.Controls.Add(grid);

            var scan=Btn("Analyze startup",Blue,160);Add(p,scan,18,395);
            var ai=Btn("AI double-check",Indigo,170);Add(p,ai,190,395);
            var disable=Btn("Disable selected",Amber,170);Add(p,disable,372,395);
            var explain=Btn("Explain selected",Card2,170);Add(p,explain,554,395);

            var note=new Label{
                Text="Nothing is disabled automatically. PC Copilot asks again and explains the tradeoff first.",
                Left=18,Top=454,Width=900,Height=28,ForeColor=Color.FromArgb(251,191,36)
            };
            p.Controls.Add(note);

            scan.Click+=async(s,e)=>{
                await RunWork("Reading startup apps and estimating their impact…","Startup analysis complete.",()=>{});
                grid.DataSource=StartupData();
                if(grid.Columns.Contains("Command"))grid.Columns["Command"].Visible=false;
                if(grid.Columns.Contains("Location"))grid.Columns["Location"].Visible=false;
                if(grid.Columns.Contains("User"))grid.Columns["User"].Visible=false;
            };

            explain.Click+=(s,e)=>{
                var row=SelectedStartup(grid);
                if(row==null){Info("Pick an item","Select a startup item first.");return;}
                ShowStartupExplanation(row,null);
            };

            ai.Click+=async(s,e)=>{
                var row=SelectedStartup(grid);
                if(row==null){Info("Pick an item","Select a startup item first.");return;}
                string q=
                    "Analyze this Windows startup item. Explain in simple English what it probably is, what it does, "+
                    "its performance impact, whether disabling it is safe, what functionality could stop working, "+
                    "and give a recommendation: KEEP, OPTIONAL, or DISABLE. Be conservative and say when uncertain.\n\n"+
                    "Name: "+row.Name+"\nPublisher: "+row.Publisher+"\nCommand: "+row.Command+"\nLocation: "+row.Location;
                string answer=await AskAI(q,false,false,settings.UseWeb);
                ShowStartupExplanation(row,answer);
            };

            disable.Click+=async(s,e)=>{
                var row=SelectedStartup(grid);
                if(row==null){Info("Pick an item","Select a startup item first.");return;}

                string aiReview="";
                string key=!string.IsNullOrWhiteSpace(settings.ApiKey)?settings.ApiKey:Environment.GetEnvironmentVariable("OPENAI_API_KEY");
                if(!string.IsNullOrWhiteSpace(key)){
                    aiReview=await AskAI(
                        "Double-check whether it is safe to disable this Windows startup item. "+
                        "Give one short verdict SAFE, CAUTION, or KEEP, then explain what may stop working. "+
                        "Be conservative.\nName: "+row.Name+"\nPublisher: "+row.Publisher+"\nCommand: "+row.Command+"\nLocation: "+row.Location,
                        false,false,settings.UseWeb);
                }

                string msg=
                    row.Name+"\n\n"+
                    "PC Copilot recommendation: "+row.Recommendation+"\n"+
                    "Likely impact: "+row.Impact+"\n\n"+
                    row.Explanation+"\n\n"+
                    (string.IsNullOrWhiteSpace(aiReview)?"AI double-check is not connected, so only the local safety analysis is available.":"AI DOUBLE-CHECK:\n"+aiReview)+"\n\n"+
                    "If you disable it, the app itself is NOT uninstalled. It simply may stop opening automatically when Windows starts.\n\n"+
                    "Do you want to continue?";

                if(!Ask("Double-check before disabling",msg))return;

                string result=DisableStartupItem(row);
                Info("Startup change",result);
                grid.DataSource=StartupData();
            };

            r.Controls.Add(p);

            var guide=CardPanel(180);
            Add(guide,H("How to read the advice"),18,15);
            Add(guide,D(
                "KEEP = Windows/security/driver/core functionality or something useful enough to leave alone.\n"+
                "OPTIONAL = Usually safe to disable from startup; the program still works when opened manually.\n"+
                "DISABLE = Common background/autostart clutter with little reason to launch every boot.\n\n"+
                "PC Copilot stays conservative when the publisher or purpose is unclear.",1000,105),18,50);
            r.Controls.Add(guide);
        }

        StartupRow SelectedStartup(DataGridView grid)
        {
            if(grid.SelectedRows.Count==0)return null;
            return grid.SelectedRows[0].DataBoundItem as StartupRow;
        }

        void ShowStartupExplanation(StartupRow row,string ai)
        {
            var sb=new StringBuilder();
            sb.AppendLine(row.Name);
            if(!string.IsNullOrWhiteSpace(row.Publisher))sb.AppendLine("Publisher: "+row.Publisher);
            sb.AppendLine();
            sb.AppendLine("Startup impact: "+row.Impact);
            sb.AppendLine("Recommendation: "+row.Recommendation);
            sb.AppendLine();
            sb.AppendLine("What it means:");
            sb.AppendLine(row.Explanation);
            sb.AppendLine();
            sb.AppendLine("If disabled:");
            sb.AppendLine("The program is not uninstalled. It simply stops launching automatically at sign-in. You can still open it normally unless it is a core Windows/driver component.");
            if(!string.IsNullOrWhiteSpace(ai)){
                sb.AppendLine();
                sb.AppendLine("AI DOUBLE-CHECK:");
                sb.AppendLine(ai);
            }
            Info("Startup item explained",sb.ToString());
        }

        string DisableStartupItem(StartupRow row)
        {
            try{
                // Conservative support: registry Run entries only.
                string loc=(row.Location??"").ToUpperInvariant();
                RegistryKey root=null;
                string sub=null;

                if(loc.Contains("HKCU")||loc.Contains("HKEY_CURRENT_USER")){
                    root=Registry.CurrentUser;
                    sub=@"Software\Microsoft\Windows\CurrentVersion\Run";
                }else if(loc.Contains("HKLM")||loc.Contains("HKEY_LOCAL_MACHINE")){
                    root=Registry.LocalMachine;
                    sub=@"Software\Microsoft\Windows\CurrentVersion\Run";
                }

                if(root==null){
                    return "For safety, this build will not automatically change that type of startup entry yet. "+
                           "It can explain it, but only clearly identified Registry Run entries can be disabled automatically.";
                }

                using(var k=root.OpenSubKey(sub,true)){
                    if(k==null)return "The startup registry location could not be opened.";
                    object value=k.GetValue(row.Name,null,RegistryValueOptions.DoNotExpandEnvironmentNames);
                    if(value==null)return "That startup value could not be found. It may have changed since the scan.";

                    string backup=Path.Combine(reportsDir,"StartupBackup_"+DateTime.Now.ToString("yyyyMMdd_HHmmss")+".txt");
                    File.AppendAllText(backup,
                        "Name="+row.Name+Environment.NewLine+
                        "Location="+row.Location+Environment.NewLine+
                        "Value="+value+Environment.NewLine+Environment.NewLine);

                    k.DeleteValue(row.Name,false);
                    WriteLog("User approved disabling startup item: "+row.Name);
                    return "Disabled "+row.Name+" from automatic startup.\n\nA text backup of the original value was saved in Reports.";
                }
            }catch(Exception ex){
                return "Could not disable this startup item: "+ex.Message;
            }
        }

        void Storage()
        {
            pageSub.Text="Find what is actually consuming space";
            var r=Root();var p=CardPanel(330);Add(p,H("Large-file finder"),18,15);
            Add(p,D("Scans Downloads, Desktop, Documents and Videos for files over 500 MB. It never deletes them automatically.",820,40),18,48);
            var box=new RichTextBox{Left=18,Top=92,Width=1000,Height=170,BackColor=Color.FromArgb(8,15,27),ForeColor=TextMain,ReadOnly=true,BorderStyle=BorderStyle.None};p.Controls.Add(box);
            var b=Btn("Find large files",Blue,170);Add(p,b,18,275);b.Click+=async(s,e)=>{await RunWork("Scanning your common personal folders for large files...","Large-file scan complete.",()=>{});box.Text=FindLargeFiles();};r.Controls.Add(p);
        }



        void EnableModernTls()
        {
            try{
                // GitHub and modern HTTPS endpoints require TLS 1.2+.
                // Numeric value 3072 keeps compatibility with older .NET Framework compilers.
                ServicePointManager.SecurityProtocol=(SecurityProtocolType)3072;
            }catch{}
        }

        bool IsNewerVersion(string remote,string local)
        {
            try{
                Version r=new Version(remote.TrimStart('v','V'));
                Version l=new Version(local.TrimStart('v','V'));
                return r>l;
            }catch{
                return !string.Equals(remote,local,StringComparison.OrdinalIgnoreCase);
            }
        }

        string Sha256File(string path)
        {
            using(var sha=SHA256.Create())
            using(var fs=File.OpenRead(path)){
                return BitConverter.ToString(sha.ComputeHash(fs)).Replace("-","").ToLowerInvariant();
            }
        }

        UpdateManifest FetchUpdateManifest()
        {
            EnableModernTls();
            if(string.IsNullOrWhiteSpace(settings.UpdateManifestUrl))
                throw new Exception("No update channel is configured yet.");

            using(var wc=new WebClient()){
                wc.Headers.Add("User-Agent","UltimatePCCopilot/"+AppVersion);
                string raw=wc.DownloadString(settings.UpdateManifestUrl);
                var js=new JavaScriptSerializer();
                var m=js.Deserialize<UpdateManifest>(raw);
                if(m==null||string.IsNullOrWhiteSpace(m.version)||string.IsNullOrWhiteSpace(m.packageUrl))
                    throw new Exception("The update manifest is missing required fields.");
                return m;
            }
        }

        async Task CheckForAppUpdate(bool interactive)
        {
            try{
                if(interactive)BeginOperation("Checking for PC Copilot updates…","Looking at the "+UpdateChannelName+" update channel.",12);

                UpdateManifest m=await Task.Run(()=>FetchUpdateManifest());
                settings.LastUpdateCheck=DateTime.Now;
                SaveSettings();

                if(!IsNewerVersion(m.version,AppVersion)){
                    if(interactive){
                        CompleteOperation("PC Copilot is up to date");
                        Info("You're current","Ultimate PC Copilot "+AppVersion+" is the newest version on your configured update channel.");
                    }
                    return;
                }

                if(interactive)CompleteOperation("Update "+m.version+" is available");

                string details=
                    "Installed: "+AppVersion+"\n"+
                    "Available: "+m.version+"\n"+
                    "Channel: "+(string.IsNullOrWhiteSpace(m.channel)?UpdateChannelName:m.channel)+"\n\n"+
                    (string.IsNullOrWhiteSpace(m.notes)?"":m.notes+"\n\n")+
                    "PC Copilot will download the update, verify its SHA-256 fingerprint, build it locally, and replace the app only if every step succeeds.";

                bool install=settings.AutoInstallUpdates;
                if(interactive&&!settings.AutoInstallUpdates)
                    install=Ask("PC Copilot update available",details+"\n\nInstall it now?");

                if(install)
                    await InstallAppUpdate(m,interactive);
                else if(interactive)
                    Info("Update available",details);
            }
            catch(Exception ex){
                if(interactive){
                    FailOperation("Could not check for updates.");
                    Info("Update check failed",ex.Message);
                }
                WriteLog("Update check failed: "+ex.Message);
            }
        }

        async Task InstallAppUpdate(UpdateManifest m,bool interactive)
        {
            if(m==null)throw new ArgumentNullException("m");

            string tempRoot=Path.Combine(Path.GetTempPath(),"UltimatePCCopilot_Update_"+Guid.NewGuid().ToString("N"));
            string zipPath=Path.Combine(tempRoot,"update.zip");
            string extractDir=Path.Combine(tempRoot,"package");
            Directory.CreateDirectory(tempRoot);
            Directory.CreateDirectory(extractDir);

            try{
                BeginOperation("Downloading PC Copilot "+m.version+"…","Pulling down the trusted update package.",18);

                await Task.Run(()=>{
                    EnableModernTls();
                    using(var wc=new WebClient()){
                        wc.Headers.Add("User-Agent","UltimatePCCopilot/"+AppVersion);
                        wc.DownloadFile(m.packageUrl,zipPath);
                    }
                });

                UpdateOperation("Verifying the package…","Checking SHA-256 so a modified download cannot sneak through.",38);

                if(!string.IsNullOrWhiteSpace(m.sha256)){
                    string actual=await Task.Run(()=>Sha256File(zipPath));
                    string expected=m.sha256.Trim().ToLowerInvariant();
                    if(!string.Equals(actual,expected,StringComparison.OrdinalIgnoreCase))
                        throw new Exception("Update verification failed. The downloaded package hash did not match the trusted manifest.");
                }else{
                    throw new Exception("The update manifest did not provide a SHA-256 fingerprint. PC Copilot refused to install it.");
                }

                UpdateOperation("Unpacking the update…","Opening the new source package in a temporary staging folder.",52);
                await Task.Run(()=>ZipFile.ExtractToDirectory(zipPath,extractDir));

                string buildBat=Directory.GetFiles(extractDir,"CHECK-AND-BUILD.bat",SearchOption.AllDirectories).FirstOrDefault();
                if(buildBat==null)
                    buildBat=Directory.GetFiles(extractDir,"BUILD-APP.bat",SearchOption.AllDirectories).FirstOrDefault();
                if(buildBat==null)
                    throw new Exception("The update package did not contain a build script.");

                string buildDir=Path.GetDirectoryName(buildBat);
                UpdateOperation("Building the new version locally…","Your own Windows compiler is creating the replacement EXE.",68);

                int exitCode=await Task.Run(()=>{
                    var psi=new ProcessStartInfo("cmd.exe","/c \""+buildBat+"\""){
                        WorkingDirectory=buildDir,
                        UseShellExecute=false,
                        CreateNoWindow=true,
                        RedirectStandardOutput=true,
                        RedirectStandardError=true
                    };
                    using(var p=Process.Start(psi)){
                        string stdout=p.StandardOutput.ReadToEnd();
                        string stderr=p.StandardError.ReadToEnd();
                        p.WaitForExit();
                        File.WriteAllText(Path.Combine(tempRoot,"build-output.txt"),stdout+Environment.NewLine+stderr);
                        return p.ExitCode;
                    }
                });

                if(exitCode!=0)
                    throw new Exception("The new version downloaded correctly but did not compile. Your current version was left untouched.");

                string newExe=Directory.GetFiles(buildDir,"UltimatePCCopilot.exe",SearchOption.TopDirectoryOnly).FirstOrDefault();
                if(newExe==null)
                    throw new Exception("The build completed but the new executable could not be found.");

                string currentExe=Application.ExecutablePath;
                string backupExe=currentExe+".previous";
                string updateScript=Path.Combine(tempRoot,"finish-update.cmd");

                UpdateOperation("Preparing the handoff…","Your current version will close, swap safely, and reopen.",88);

                string script=
                    "@echo off\r\n"+
                    "timeout /t 2 /nobreak >nul\r\n"+
                    "if exist \""+backupExe+"\" del /f /q \""+backupExe+"\"\r\n"+
                    "move /y \""+currentExe+"\" \""+backupExe+"\" >nul\r\n"+
                    "copy /y \""+newExe+"\" \""+currentExe+"\" >nul\r\n"+
                    "if errorlevel 1 (\r\n"+
                    "  if exist \""+backupExe+"\" move /y \""+backupExe+"\" \""+currentExe+"\" >nul\r\n"+
                    "  exit /b 1\r\n"+
                    ")\r\n"+
                    "start \"\" \""+currentExe+"\"\r\n"+
                    "exit /b 0\r\n";
                File.WriteAllText(updateScript,script,Encoding.ASCII);

                CompleteOperation("Update "+m.version+" is ready");
                Info("Ready to update","PC Copilot will now close, install "+m.version+", and reopen automatically.");

                Process.Start(new ProcessStartInfo("cmd.exe","/c \""+updateScript+"\""){
                    UseShellExecute=true,
                    WindowStyle=ProcessWindowStyle.Hidden
                });
                Application.Exit();
            }
            catch(Exception ex){
                FailOperation("Update stopped safely.");
                WriteLog("Update install failed: "+ex.Message);
                if(interactive)Info("Update not installed",ex.Message+"\n\nYour current PC Copilot version was not replaced.");
            }
        }

        async Task AutoUpdateCheckIfDue()
        {
            if(!settings.AutoInstallUpdates||string.IsNullOrWhiteSpace(settings.UpdateManifestUrl))return;
            if(DateTime.Now-settings.LastUpdateCheck<TimeSpan.FromHours(24))return;
            await CheckForAppUpdate(false);
        }

        void Updates()
        {
            pageSub.Text="PC Copilot updates + Windows and Defender updates";
            var r=Root();

            var app=CardPanel(285);
            Add(app,H("PC Copilot Update Center"),18,15);
            Add(app,D(
                "Installed version: "+AppVersion+" • Channel: "+UpdateChannelName+"\n"+
                "Once an update channel URL is configured, future versions can download, verify, build, install, and relaunch themselves without emailing ZIP files.",
                1010,55),18,48);

            var check=Btn("Check for app update",Indigo,190);Add(app,check,18,120);
            var auto=new CheckBox{
                Text="Automatically install trusted updates",
                Checked=settings.AutoInstallUpdates,
                Left=225,Top=131,Width=290,Height=24,
                ForeColor=TextMain
            };
            app.Controls.Add(auto);

            var urlLabel=new Label{
                Text="Update manifest URL",
                Left=18,Top=178,Width=180,Height=22,
                ForeColor=Muted
            };
            app.Controls.Add(urlLabel);

            var url=new TextBox{
                Text=settings.UpdateManifestUrl,
                Left=18,Top=202,Width=760,Height=32,
                BackColor=Color.FromArgb(8,15,27),
                ForeColor=TextMain,
                BorderStyle=BorderStyle.FixedSingle
            };
            app.Controls.Add(url);

            var save=Btn("Save update channel",Card2,185);Add(app,save,795,200);

            var safety=new Label{
                Text="Safety: PC Copilot refuses an update unless the downloaded ZIP matches the SHA-256 hash in the trusted manifest.",
                Left=18,Top=246,Width=990,Height=25,
                ForeColor=Color.FromArgb(52,211,153)
            };
            app.Controls.Add(safety);

            check.Click+=async(s,e)=>{
                settings.UpdateManifestUrl=url.Text.Trim();
                settings.AutoInstallUpdates=auto.Checked;
                SaveSettings();
                await CheckForAppUpdate(true);
            };
            save.Click+=(s,e)=>{
                settings.UpdateManifestUrl=url.Text.Trim();
                settings.AutoInstallUpdates=auto.Checked;
                SaveSettings();
                Info("Update channel saved",
                    string.IsNullOrWhiteSpace(settings.UpdateManifestUrl)
                    ?"The updater is ready, but it needs a manifest URL before it can check online."
                    :"Future checks will use this update channel.");
            };
            auto.CheckedChanged+=(s,e)=>{
                settings.AutoInstallUpdates=auto.Checked;
                SaveSettings();
            };
            r.Controls.Add(app);

            var p=CardPanel(210);Add(p,H("Windows & Security Updates"),18,15);
            Add(p,D("Security intelligence can be updated directly. Windows Update opens the official Windows settings page so Windows remains in control of system updates.",820,45),18,50);
            var d=Btn("Update Defender",Teal,170);Add(p,d,18,112);d.Click+=async(s,e)=>await RunWork("Downloading current Microsoft security intelligence...","Defender updated.",DefenderUpdate);
            var w=Btn("Open Windows Update",Blue,190);Add(p,w,200,112);w.Click+=(s,e)=>Process.Start("ms-settings:windowsupdate");
            var web=Btn("Ask AI about current issue",Indigo,210);Add(p,web,403,112);web.Click+=async(s,e)=>{string ans=await AskAI("Check current information relevant to the PC/security/update issue I am asking about. Ask me what I need if no specific issue is stated.",false,true,true);Info("AI current lookup",ans);};r.Controls.Add(p);
        }

        void Reports()
        {
            pageSub.Text="Diagnostic, malware, and security reports";
            var r=Root();var p=CardPanel(360);Add(p,H("Reports"),18,15);
            var list=new ListBox{Left=18,Top=55,Width=800,Height=230,BackColor=Color.FromArgb(8,15,27),ForeColor=TextMain,BorderStyle=BorderStyle.FixedSingle};p.Controls.Add(list);
            Action refresh=()=>{list.Items.Clear();foreach(var f in Directory.GetFiles(reportsDir).OrderByDescending(File.GetLastWriteTime))list.Items.Add(f);};refresh();
            var open=Btn("Open selected",Blue,150);Add(p,open,680,55);open.Click+=(s,e)=>{if(list.SelectedItem!=null)Process.Start((string)list.SelectedItem);};
            var folder=Btn("Open folder",Card2,150);Add(p,folder,680,105);folder.Click+=(s,e)=>Process.Start("explorer.exe",reportsDir);
            var diag=Btn("New deep report",Indigo,150);Add(p,diag,680,155);diag.Click+=async(s,e)=>{await RunWork("Collecting deep system evidence...","Deep report created.",()=>CreateDiagnostic(""));refresh();};
            r.Controls.Add(p);
        }

        void SettingsPage()
        {
            pageSub.Text="AI connection, privacy, and local memory";
            var r=Root();var p=CardPanel(340);Add(p,H("AI connection"),18,15);
            Add(p,D("API requests are separate from the ChatGPT app. Your API key stays in this local settings file. For stronger security, use an environment variable instead.",820,52),18,48);
            var key=new TextBox{Left=18,Top=112,Width=600,Height=33,BackColor=Color.FromArgb(8,15,27),ForeColor=TextMain,UseSystemPasswordChar=true,Text=settings.ApiKey,BorderStyle=BorderStyle.FixedSingle};p.Controls.Add(key);
            var model=new TextBox{Left=18,Top=162,Width=280,Height=33,BackColor=Color.FromArgb(8,15,27),ForeColor=TextMain,Text=settings.Model,BorderStyle=BorderStyle.FixedSingle};p.Controls.Add(model);
            var web=new CheckBox{Text="Allow optional current web lookup",Checked=settings.UseWeb,Left=18,Top=210,AutoSize=true,ForeColor=TextMain};p.Controls.Add(web);
            var save=Btn("Save settings",Indigo,160);Add(p,save,18,255);save.Click+=(s,e)=>{settings.ApiKey=key.Text.Trim();settings.Model=model.Text.Trim();settings.UseWeb=web.Checked;SaveSettings();Info("Saved","Settings saved locally.");};
            var wipe=Btn("Erase Copilot memory",Red,190);Add(p,wipe,195,255);wipe.Click+=(s,e)=>{if(Ask("Erase memory","Delete all adaptive notes saved inside this app?")){settings.Memory.Clear();SaveSettings();Info("Erased","Local Copilot memory was cleared.");}};
            r.Controls.Add(p);
        }



        string[] ScanCoverageRoots()
        {
            var roots=new List<string>();
            try{roots.Add(Environment.GetFolderPath(Environment.SpecialFolder.Windows));}catch{}
            try{roots.Add(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles));}catch{}
            try{roots.Add(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86));}catch{}
            try{roots.Add(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile));}catch{}
            try{roots.Add(Path.GetTempPath());}catch{}
            return roots.Where(x=>!string.IsNullOrWhiteSpace(x)&&Directory.Exists(x)).Distinct().ToArray();
        }

        Task StartCoverageFeed(ConcurrentQueue<string> queue,System.Threading.CancellationToken token)
        {
            return Task.Run(()=>{
                foreach(string root in ScanCoverageRoots()){
                    if(token.IsCancellationRequested)break;
                    try{
                        var pending=new Stack<string>();
                        pending.Push(root);
                        int safety=0;
                        while(pending.Count>0&&!token.IsCancellationRequested&&safety<45000){
                            string dir=pending.Pop();
                            safety++;
                            try{
                                foreach(string file in Directory.EnumerateFiles(dir)){
                                    if(token.IsCancellationRequested)break;
                                    queue.Enqueue(file);
                                    while(queue.Count>300){
                                        string junk;
                                        queue.TryDequeue(out junk);
                                    }
                                }
                            }catch{}
                            try{
                                foreach(string sub in Directory.EnumerateDirectories(dir)){
                                    if(token.IsCancellationRequested)break;
                                    string low=sub.ToLowerInvariant();
                                    if(low.Contains("\\winsxs\\backup")||low.Contains("\\system volume information"))continue;
                                    pending.Push(sub);
                                }
                            }catch{}
                        }
                    }catch{}
                }
            },token);
        }

        string ScanZoneFromPath(string path)
        {
            if(string.IsNullOrWhiteSpace(path))return "Checking Windows and application files";
            string low=path.ToLowerInvariant();
            string user=Environment.GetFolderPath(Environment.SpecialFolder.UserProfile).ToLowerInvariant();
            string win=Environment.GetFolderPath(Environment.SpecialFolder.Windows).ToLowerInvariant();
            string pf=Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles).ToLowerInvariant();

            if(low.StartsWith(win))return "Windows system territory";
            if(low.StartsWith(pf)||low.Contains("\\program files (x86)\\"))return "Installed applications";
            if(!string.IsNullOrWhiteSpace(user)&&low.StartsWith(user)){
                if(low.Contains("\\appdata\\"))return "User app data & caches";
                if(low.Contains("\\downloads\\"))return "Downloads";
                if(low.Contains("\\desktop\\"))return "Desktop";
                return "Your user files";
            }
            if(low.Contains("\\temp\\"))return "Temporary-file hiding spots";
            return "Local files";
        }

        string ShortPath(string path,int max)
        {
            if(string.IsNullOrWhiteSpace(path))return "";
            if(path.Length<=max)return path;
            return "…"+path.Substring(path.Length-max+1);
        }


        class ScanTroubleReport
        {
            public string Summary;
            public string Detail;
            public string SuggestedFix;
            public string FixId;
            public bool CanAutoFix;
        }

        ScanTroubleReport DiagnoseSlowScan(string scanTitle,string stageName,TimeSpan elapsed)
        {
            var r=new ScanTroubleReport{
                Summary="The scan is still running.",
                Detail="PC Copilot did not find a clear failure yet.",
                SuggestedFix="Give Defender more time.",
                FixId="NONE",
                CanAutoFix=false
            };

            try{
                string defender=RunPS("$s=Get-MpComputerStatus;"+
                    "\"RT=$($s.RealTimeProtectionEnabled)`nAV=$($s.AntivirusEnabled)`n"+
                    "SigAge=$([int]((Get-Date)-$s.AntivirusSignatureLastUpdated).TotalHours)`n"+
                    "QuickAge=$([int]((Get-Date)-$s.QuickScanEndTime).TotalHours)`n"+
                    "FullAge=$([int]((Get-Date)-$s.FullScanEndTime).TotalHours)\"");

                string proc=RunPS("Get-Process MsMpEng -ErrorAction SilentlyContinue | "+
                    "Select CPU,@{n='RAMMB';e={[math]::Round($_.WorkingSet64/1MB,0)}} | Format-List | Out-String");

                string disk=RunPS("Get-CimInstance Win32_PerfFormattedData_PerfDisk_PhysicalDisk -ErrorAction SilentlyContinue | "+
                    "? {$_.Name -eq '_Total'} | Select PercentDiskTime,AvgDiskQueueLength,DiskBytesPersec | Format-List | Out-String");

                double free=SystemFreeGB();

                if(defender.Contains("RT=False")||defender.Contains("AV=False")){
                    r.Summary="Windows Defender protection does not look fully active.";
                    r.Detail="The scan may be behaving strangely because antivirus or real-time protection is not fully enabled.";
                    r.SuggestedFix="Re-check Defender health and attempt to re-enable normal protection.";
                    r.FixId="DEFENDER_HEALTH";
                    r.CanAutoFix=true;
                    return r;
                }

                var sig=Regex.Match(defender,@"SigAge=(\d+)");
                int sigAge=0;
                if(sig.Success)int.TryParse(sig.Groups[1].Value,out sigAge);
                if(sigAge>48){
                    r.Summary="Your Defender security intelligence is stale.";
                    r.Detail="Old threat definitions can slow or complicate scans because Defender may update while scanning.";
                    r.SuggestedFix="Refresh Defender security intelligence, then continue.";
                    r.FixId="DEFENDER_UPDATE";
                    r.CanAutoFix=true;
                    return r;
                }

                if(free<3){
                    r.Summary="Your system drive is very low on free space.";
                    r.Detail="Security scans and Windows maintenance can slow down badly when the system drive has almost no working room.";
                    r.SuggestedFix="Run safe temporary-file cleanup to free working space.";
                    r.FixId="SAFE_CLEAN";
                    r.CanAutoFix=true;
                    return r;
                }

                var dq=Regex.Match(disk,@"AvgDiskQueueLength\s*:\s*([0-9.]+)");
                double q=0;
                if(dq.Success)double.TryParse(dq.Groups[1].Value,out q);
                if(q>=4){
                    r.Summary="The drive looks heavily backed up.";
                    r.Detail="The disk queue is high, so Defender may simply be waiting for storage I/O rather than being frozen.";
                    r.SuggestedFix="Close heavy disk users if possible and let the scan continue. PC Copilot should not reset Defender for this.";
                    r.FixId="NONE";
                    r.CanAutoFix=false;
                    return r;
                }

                if(proc.IndexOf("MsMpEng",StringComparison.OrdinalIgnoreCase)>=0 || proc.Contains("CPU")){
                    r.Summary="Defender appears to still be actively working.";
                    r.Detail="The Microsoft antimalware process is present and the app is responsive. This usually means the scan is slow, not stuck.";
                    r.SuggestedFix="Let it keep going unless the watchdog reaches the hard-warning threshold.";
                    r.FixId="NONE";
                    r.CanAutoFix=false;
                    return r;
                }

                if(elapsed.TotalMinutes>10 && stageName.ToLowerInvariant().Contains("scan")){
                    r.Summary="The scan has run a long time and Defender activity is unclear.";
                    r.Detail="PC Copilot cannot confirm healthy scan activity from the usual signals.";
                    r.SuggestedFix="Refresh Defender health and retry the current scan only after confirmation.";
                    r.FixId="DEFENDER_RECOVER";
                    r.CanAutoFix=true;
                    return r;
                }
            }catch(Exception ex){
                r.Detail="Troubleshooter could not inspect every signal: "+ex.Message;
            }

            return r;
        }

        string ApplyScanFix(string fixId)
        {
            try{
                if(fixId=="DEFENDER_UPDATE"){
                    DefenderUpdate();
                    return "Defender security intelligence was refreshed.";
                }
                if(fixId=="SAFE_CLEAN"){
                    SafeCleanup();
                    return "Safe temporary-file cleanup finished. Personal files were not touched.";
                }
                if(fixId=="DEFENDER_HEALTH"){
                    RunPS("Set-MpPreference -DisableRealtimeMonitoring $false");
                    DefenderUpdate();
                    return "PC Copilot asked Windows Defender to restore normal real-time monitoring and refreshed security intelligence.";
                }
                if(fixId=="DEFENDER_RECOVER"){
                    DefenderUpdate();
                    RunPS("Get-MpComputerStatus | Out-String");
                    return "PC Copilot refreshed Defender intelligence and re-checked antivirus health. If the current scan still does not finish, return to the app and start a fresh scan.";
                }
                return "No automatic fix was needed.";
            }catch(Exception ex){
                return "Automatic recovery could not complete: "+ex.Message;
            }
        }

        async Task ShowDetailedScan(
            string scanTitle,
            string intro,
            string[] stages,
            int[] expectedSeconds,
            Action[] actions,
            Func<string> resultBuilder)
        {
            var f=new Form{
                Text=scanTitle,
                Size=new Size(930,780),
                MinimumSize=new Size(800,680),
                StartPosition=FormStartPosition.CenterParent,
                BackColor=Bg,
                ForeColor=TextMain
            };

            var title=new Label{Text=scanTitle,Left=28,Top=22,AutoSize=true,ForeColor=TextMain,Font=new Font("Segoe UI Semibold",22,FontStyle.Bold)};
            var sub=new Label{Text=intro,Left=30,Top=60,Width=840,Height=44,ForeColor=Muted};

            var overallLabel=new Label{Text="Overall progress",Left=30,Top=112,Width=250,Height=24,ForeColor=TextMain,Font=new Font("Segoe UI Semibold",10,FontStyle.Bold)};
            var eta=new Label{Text="Estimated time: warming up…",Left=605,Top=112,Width=265,Height=24,ForeColor=Muted,TextAlign=ContentAlignment.MiddleRight};
            var overall=new ProgressBar{Left=30,Top=139,Width=840,Height=16,Minimum=0,Maximum=100,Value=0};

            var stageTitle=new Label{Text="Getting our gloves on…",Left=30,Top=174,Width=680,Height=28,ForeColor=Color.FromArgb(165,180,252),Font=new Font("Segoe UI Semibold",13,FontStyle.Bold)};
            var stageDetail=new Label{Text="Preparing the scan.",Left=30,Top=206,Width=840,Height=26,ForeColor=Muted};
            var stageBar=new ProgressBar{Left=30,Top=238,Width=840,Height=13,Minimum=0,Maximum=100,Value=0};
            var estimatedTag=new Label{
                Text="Estimated stage progress — PC Copilot never fakes a Defender-reported percentage",
                Left=30,Top=256,Width=560,Height=22,
                ForeColor=Color.FromArgb(100,116,139),Font=new Font("Segoe UI",8)
            };

            var list=new ListBox{
                Left=30,Top=287,Width=840,Height=148,
                BackColor=Color.FromArgb(8,15,27),
                ForeColor=TextMain,BorderStyle=BorderStyle.FixedSingle
            };
            for(int i=0;i<stages.Length;i++)list.Items.Add("○  "+(i+1)+" of "+stages.Length+"  "+stages[i]);

            var feedTitle=new Label{
                Text="LIVE COVERAGE FEED",Left=30,Top=451,Width=250,Height=21,
                ForeColor=TextMain,Font=new Font("Segoe UI Semibold",9,FontStyle.Bold)
            };
            var feedZone=new Label{
                Text="Waiting for the file sweep…",Left=250,Top=451,Width=620,Height=21,
                ForeColor=Color.FromArgb(165,180,252),TextAlign=ContentAlignment.MiddleRight
            };
            var fileMini=new ProgressBar{
                Left=30,Top=477,Width=840,Height=7,
                Minimum=0,Maximum=100,Value=0,Style=ProgressBarStyle.Marquee
            };
            var currentFile=new Label{
                Text="No file activity yet.",Left=30,Top=493,Width=840,Height=24,
                ForeColor=Color.FromArgb(203,213,225),Font=new Font("Consolas",8.5f)
            };
            var feedNote=new Label{
                Text="Real files PC Copilot is discovering during the Defender scan. Defender does not expose its exact current filename to this app.",
                Left=30,Top=517,Width=840,Height=34,
                ForeColor=Color.FromArgb(100,116,139),Font=new Font("Segoe UI",8)
            };

            var result=new RichTextBox{
                Left=30,Top=566,Width=840,Height=105,
                BackColor=Color.FromArgb(8,15,27),
                ForeColor=TextMain,ReadOnly=true,BorderStyle=BorderStyle.None,Visible=false
            };

            var whyBtn=Btn("What's taking so long?",Amber,190);
            whyBtn.Left=500;whyBtn.Top=685;

            var cancelBtn=Btn("Return to app",Card2,150);
            cancelBtn.Left=720;cancelBtn.Top=685;

            var heartbeat=new Label{
                Text="Heartbeat: ready",
                Left=30,Top=690,Width=450,Height=24,
                ForeColor=Color.FromArgb(100,116,139)
            };

            f.Controls.AddRange(new Control[]{
                title,sub,overallLabel,eta,overall,stageTitle,stageDetail,stageBar,
                estimatedTag,list,feedTitle,feedZone,fileMini,currentFile,feedNote,result,
                whyBtn,cancelBtn,heartbeat
            });

            // Scan state must exist before any button/event handler can reference it.
            var totalWatch=Stopwatch.StartNew();
            int totalExpected=Math.Max(1,expectedSeconds.Sum());
            int currentStage=0;
            DateTime stageStarted=DateTime.Now;
            bool stageRunning=false;
            double lastRemaining=totalExpected;
            int heartbeatTick=0;
            bool userReturned=false;

            whyBtn.Click+=async(s,e)=>{
                whyBtn.Enabled=false;
                string oldText=whyBtn.Text;
                whyBtn.Text="Checking…";
                try{
                    TimeSpan elapsed=DateTime.Now-stageStarted;
                    ScanTroubleReport tr=await Task.Run(()=>DiagnoseSlowScan(
                        scanTitle,
                        currentStage<stages.Length?stages[currentStage]:"",
                        elapsed
                    ));

                    string message=
                        tr.Summary+"\n\n"+
                        tr.Detail+"\n\n"+
                        "My advice:\n"+tr.SuggestedFix;

                    if(tr.CanAutoFix){
                        message+="\n\nPC Copilot found a low-risk recovery it can perform now. Apply it?";
                        if(Ask("What's taking so long?",message)){
                            string fixResult=await Task.Run(()=>ApplyScanFix(tr.FixId));
                            Info("PC Copilot recovery",fixResult);
                            WriteLog("Slow-scan recovery "+tr.FixId+": "+fixResult);
                        }
                    }else{
                        Info("What's taking so long?",message);
                    }
                }finally{
                    whyBtn.Text=oldText;
                    whyBtn.Enabled=true;
                }
            };

            cancelBtn.Click+=(s,e)=>{
                userReturned=true;
                f.Hide();
            };

            f.Show(this);

            var coverageQueue=new ConcurrentQueue<string>();
            var coverageCancel=new System.Threading.CancellationTokenSource();
            Task coverageTask=StartCoverageFeed(coverageQueue,coverageCancel.Token);

            int filesDisplayed=0;

            var uiTimer=new System.Windows.Forms.Timer{Interval=250};
            uiTimer.Tick+=(s,e)=>{
                if(!stageRunning)return;

                int expected=Math.Max(1,expectedSeconds[currentStage]);
                double elapsed=(DateTime.Now-stageStarted).TotalSeconds;

                int est=(int)Math.Min(94,Math.Round((1-Math.Exp(-elapsed/Math.Max(8.0,expected*0.45)))*94.0));
                stageBar.Value=Math.Max(stageBar.Value,Math.Max(2,est));

                int completedWeight=0;
                for(int j=0;j<currentStage;j++)completedWeight+=expectedSeconds[j];
                double currentContribution=Math.Min(expectedSeconds[currentStage]*0.94,
                    expectedSeconds[currentStage]*(stageBar.Value/100.0));
                int op=(int)Math.Min(97,Math.Round((completedWeight+currentContribution)/totalExpected*100.0));
                overall.Value=Math.Max(overall.Value,Math.Max(1,op));

                double rawRemaining=totalExpected-totalWatch.Elapsed.TotalSeconds;
                if(rawRemaining>0){
                    lastRemaining=Math.Min(lastRemaining,rawRemaining);
                    eta.Text="Estimated remaining: "+FriendlyDuration(TimeSpan.FromSeconds(lastRemaining));
                }else{
                    eta.Text="Taking longer than usual — still digging…";
                }

                string path;
                int drained=0;
                string newest=null;
                while(drained<8&&coverageQueue.TryDequeue(out path)){
                    newest=path;
                    drained++;
                    filesDisplayed++;
                }

                if(newest!=null){
                    currentFile.Text="↳ "+ShortPath(newest,105);
                    feedZone.Text=ScanZoneFromPath(newest)+" • "+filesDisplayed.ToString("N0")+" files surfaced";
                }else if(currentStage>0){
                    feedZone.Text="Defender is still working • waiting for the next file path";
                }

                heartbeatTick++;
                string[] beats={"still alive ✓","UI responsive ✓","Defender call active ✓","no freeze here ✓"};
                heartbeat.Text="Heartbeat: "+beats[heartbeatTick%beats.Length]+" • "+FriendlyDuration(totalWatch.Elapsed);

                if(currentStage<stages.Length && stages[currentStage].ToLowerInvariant().Contains("scanning")){
                    if(elapsed<15) stageDetail.Text=stages[currentStage]+" — getting the sweep moving";
                    else if(elapsed<60) stageDetail.Text=stages[currentStage]+" — checking the usual hiding spots";
                    else if(elapsed<300) stageDetail.Text=stages[currentStage]+" — still chewing through files, nothing is frozen";
                    else stageDetail.Text=stages[currentStage]+" — deep in the file pile; Defender is still running";
                }

                // Watchdog: never silently sit forever.
                double softLimit=Math.Max(90,expected*2.0);
                double hardLimit=Math.Max(180,expected*4.0);

                if(elapsed>softLimit && elapsed<=hardLimit){
                    eta.Text="Longer than expected — Defender is still working";
                    stageTitle.Text="Still running — this one is taking its sweet time";
                    stageDetail.Text=stages[currentStage]+" — PC Copilot is responsive and still waiting on Windows Defender.";
                }
                else if(elapsed>hardLimit){
                    eta.Text="Watchdog warning — unusually long stage";
                    stageTitle.Text="⚠ Watchdog: Defender is taking unusually long";
                    stageDetail.Text="PC Copilot itself is NOT frozen. You can return to the app now; Defender may continue scanning in Windows Security.";
                    heartbeat.ForeColor=Color.FromArgb(245,158,11);
                }
            };
            uiTimer.Start();

            try{
                for(int i=0;i<stages.Length;i++){
                    currentStage=i;
                    stageStarted=DateTime.Now;
                    stageRunning=true;
                    stageBar.Value=2;
                    list.Items[i]="▶  "+(i+1)+" of "+stages.Length+"  "+stages[i];
                    list.SelectedIndex=i;

                    string fun=StageFlavor(i+1,stages.Length,stages[i]);
                    stageTitle.Text=(i+1)+" of "+stages.Length+" — "+fun;
                    stageDetail.Text=stages[i];
                    WriteLog(scanTitle+": "+stages[i]);

                    var stageTask=Task.Run(actions[i]);

                    // Keep waiting for the real Windows operation, but never block the UI thread.
                    while(!stageTask.IsCompleted){
                        await Task.Delay(500);

                        // If user returned to the main app, keep the underlying task alive without
                        // freezing the application. The tray/log remain usable.
                        if(userReturned){
                            WriteLog(scanTitle+" continues in the background: "+stages[i]);
                        }
                    }

                    // Surface exceptions if the underlying Windows command failed.
                    await stageTask;

                    stageRunning=false;
                    stageBar.Value=100;
                    list.Items[i]="✓  "+(i+1)+" of "+stages.Length+"  "+stages[i];
                    int complete=(int)Math.Round((i+1)*100.0/stages.Length);
                    overall.Value=Math.Max(overall.Value,Math.Min(100,complete));
                    await Task.Delay(220);
                }

                overall.Value=100;
                stageBar.Value=100;
                eta.Text="Finished in "+FriendlyDuration(totalWatch.Elapsed);
                stageTitle.Text="✓ All done — we survived the file jungle";
                stageDetail.Text="The scan finished. Turning the nerdy bits into normal English.";
                estimatedTag.Text="Completed";
                fileMini.Style=ProgressBarStyle.Blocks;
                fileMini.Value=100;
                feedZone.Text="Coverage feed finished • "+filesDisplayed.ToString("N0")+" file paths surfaced";

                result.Visible=true;
                result.Text=resultBuilder!=null?resultBuilder():"Scan completed successfully.";
                list.SelectedIndex=-1;
                heartbeat.Text="Heartbeat: finished ✓";
                cancelBtn.Text="Close";
                WriteLog(scanTitle+" complete.");

                if(userReturned){
                    tray.ShowBalloonTip(
                        4500,
                        "PC Copilot scan finished",
                        scanTitle+" completed in the background.",
                        ToolTipIcon.Info
                    );
                }
            }
            catch(Exception ex){
                stageRunning=false;
                stageTitle.Text="⚠ Something got in the way";
                stageDetail.Text="The scan hit an error. The activity log has the technical details.";
                result.Visible=true;
                result.Text="Error: "+ex.Message;
                WriteLog("ERROR during "+scanTitle+": "+ex.Message);
            }
            finally{
                coverageCancel.Cancel();
                uiTimer.Stop();
                totalWatch.Stop();
                stageRunning=false;
                if(!f.IsDisposed && f.Visible){
                    heartbeat.Text="Heartbeat: stopped";
                }
            }
        }


        string FriendlyDuration(TimeSpan t)
        {
            if(t.TotalSeconds<60)return Math.Max(1,(int)Math.Round(t.TotalSeconds))+" sec";
            if(t.TotalMinutes<60)return ((int)t.TotalMinutes)+" min "+t.Seconds+" sec";
            return ((int)t.TotalHours)+" hr "+t.Minutes+" min";
        }

        string BuildDefenderSummary(string scanType)
        {
            try{
                string status=RunPS("$s=Get-MpComputerStatus;$t=Get-MpThreatDetection;"+
                    "\"Realtime=$($s.RealTimeProtectionEnabled)`nBehavior=$($s.BehaviorMonitorEnabled)`nUpdated=$($s.AntivirusSignatureLastUpdated)`nThreatCount=$(@($t).Count)\"");
                int threatCount=0;
                var m=Regex.Match(status,@"ThreatCount=(\d+)");
                if(m.Success)int.TryParse(m.Groups[1].Value,out threatCount);

                var sb=new StringBuilder();
                sb.AppendLine(scanType+" finished.");
                sb.AppendLine();
                if(threatCount==0){
                    sb.AppendLine("✓ Defender did not return any recorded threat detections.");
                    sb.AppendLine("Advice: Good result. Keep real-time protection on and continue normal Windows/security updates.");
                }else{
                    sb.AppendLine("⚠ Defender has "+threatCount+" recorded threat detection(s).");
                    sb.AppendLine("Advice: Open Threat History next. Do not restore or allow anything you do not recognize.");
                }
                sb.AppendLine();
                sb.AppendLine("Real-time protection: "+(status.Contains("Realtime=True")?"ON":"CHECK NEEDED"));
                sb.AppendLine("Behavior monitoring: "+(status.Contains("Behavior=True")?"ON":"CHECK NEEDED"));
                sb.AppendLine();
                sb.AppendLine("Note: The moving percentages during Defender's scan stage are estimates because Windows reports scan completion but does not provide this app a trustworthy per-file percentage.");
                return sb.ToString();
            }catch(Exception ex){
                return scanType+" completed, but PC Copilot could not build the plain-English summary: "+ex.Message;
            }
        }

        async Task RunWork(string doing,string done,Action a)
        {
            BeginOperation(doing,"Working through it now...",10);
            try{
                await Task.Run(a);
                CompleteOperation(done);
            }
            catch(Exception ex){
                WriteLog("ERROR: "+ex.Message);
                FailOperation("That run hit an error. Check the activity log.");
            }
        }

        async Task RunStages(string title,string done,string[] stageNames,Action[] stageActions)
        {
            if(stageNames==null||stageActions==null||stageNames.Length==0||stageNames.Length!=stageActions.Length){
                await RunWork(title,done,()=>{});
                return;
            }

            BeginOperation("Starting up…","Getting everything ready.",2);

            try{
                for(int i=0;i<stageNames.Length;i++){
                    int current=i+1;
                    int pct=(int)Math.Round((i*100.0)/stageNames.Length);
                    string fun=StageFlavor(current,stageNames.Length,stageNames[i]);
                    UpdateOperation("Stage "+current+" of "+stageNames.Length+" — "+fun,stageNames[i],Math.Max(3,pct));
                    int copy=i;
                    await Task.Run(stageActions[copy]);

                    int after=(int)Math.Round((current*100.0)/stageNames.Length);
                    progress.Value=Math.Min(96,Math.Max(progress.Value,after));
                }
                CompleteOperation(done);
            }
            catch(Exception ex){
                WriteLog("ERROR: "+ex.Message);
                FailOperation("Something tripped us up. Check the activity log.");
            }
        }

        string StageFlavor(int stage,int total,string raw)
        {
            string lower=(raw??"").ToLowerInvariant();
            if(lower.Contains("update")||lower.Contains("definition")||lower.Contains("intelligence"))return "Freshening up the threat radar";
            if(lower.Contains("scan")||lower.Contains("malware"))return "Digging through the suspicious stuff";
            if(lower.Contains("threat")||lower.Contains("review"))return "Checking what turned up";
            if(lower.Contains("diagnostic")||lower.Contains("collect"))return "Taking your PC's vitals";
            if(lower.Contains("cleanup")||lower.Contains("clean"))return "Sweeping out the junk drawer";
            if(lower.Contains("repair")||lower.Contains("dism"))return "Patching up Windows";
            if(lower.Contains("sfc")||lower.Contains("system file"))return "Checking Windows' important files";
            if(lower.Contains("disk")||lower.Contains("chkdsk")||lower.Contains("storage"))return "Giving the drive a once-over";
            if(lower.Contains("network")||lower.Contains("dns")||lower.Contains("winsock"))return "Straightening out the network";
            if(stage==total)return "Wrapping it up";
            return "Working through the next check";
        }

        void BeginOperation(string stage,string detail,int pct)
        {
            if(InvokeRequired){BeginInvoke(new Action(()=>BeginOperation(stage,detail,pct)));return;}
            operationWatch.Reset();operationWatch.Start();operationTimer.Start();
            progress.Style=ProgressBarStyle.Blocks;
            progress.Value=Math.Max(0,Math.Min(100,pct));
            progressStage.Text=stage;
            progressDetail.Text=detail;
            progressElapsed.Text="Elapsed 0:00";
            headerStatus.Text="● Working";
            headerStatus.ForeColor=Blue;
            WriteLog(stage+" — "+detail);
        }

        void UpdateOperation(string stage,string detail,int pct)
        {
            if(InvokeRequired){BeginInvoke(new Action(()=>UpdateOperation(stage,detail,pct)));return;}
            progress.Value=Math.Max(0,Math.Min(99,pct));
            progressStage.Text=stage;
            progressDetail.Text=detail;
            headerStatus.Text="● Working";
            headerStatus.ForeColor=Blue;
            WriteLog(stage+" — "+detail);
        }

        void CompleteOperation(string done)
        {
            if(InvokeRequired){BeginInvoke(new Action(()=>CompleteOperation(done)));return;}
            operationWatch.Stop();operationTimer.Stop();
            progress.Value=100;
            progressStage.Text="✓ DONE — "+done;
            progressDetail.Text="All finished. You're good to go.";
            progressElapsed.Text="Finished in "+(operationWatch.Elapsed.TotalHours>=1?operationWatch.Elapsed.ToString(@"h\:mm\:ss"):operationWatch.Elapsed.ToString(@"m\:ss"));
            headerStatus.Text="● Done";
            headerStatus.ForeColor=Green;
            WriteLog("DONE: "+done);
            System.Media.SystemSounds.Asterisk.Play();
        }

        void FailOperation(string msg)
        {
            if(InvokeRequired){BeginInvoke(new Action(()=>FailOperation(msg)));return;}
            operationWatch.Stop();operationTimer.Stop();
            progress.Value=0;
            progressStage.Text="⚠ Needs attention";
            progressDetail.Text=msg;
            progressElapsed.Text="";
            headerStatus.Text="● Error";
            headerStatus.ForeColor=Red;
        }

        void SetBusy(bool b,string s)
        {
            if(b)BeginOperation(s,"Working through it now...",10);
            else CompleteOperation(s);
        }
        void WriteLog(string s)
        {
            string line="["+DateTime.Now.ToString("HH:mm:ss")+"] "+s;
            try{File.AppendAllText(logFile,line+Environment.NewLine);}catch{}
            if(log!=null&&!log.IsDisposed){if(log.InvokeRequired)log.BeginInvoke(new Action(()=>{log.AppendText(line+Environment.NewLine);log.ScrollToCaret();}));else{log.AppendText(line+Environment.NewLine);log.ScrollToCaret();}}
        }

        void SetupTray()
        {
            tray=new NotifyIcon{Icon=SystemIcons.Shield,Text="Ultimate PC Copilot",Visible=true};
            var m=new ContextMenuStrip();
            m.Items.Add("Open",null,(s,e)=>{Show();WindowState=FormWindowState.Normal;Activate();});
            m.Items.Add("Open Copilot overlay",null,(s,e)=>ShowOverlay());
            m.Items.Add("Quick malware scan",null,async(s,e)=>await RunWork("Running quick malware scan...","Malware scan finished.",DefenderQuick));
            m.Items.Add(new ToolStripSeparator());
            m.Items.Add("Exit",null,(s,e)=>Application.Exit());
            tray.ContextMenuStrip=m;tray.DoubleClick+=(s,e)=>{Show();WindowState=FormWindowState.Normal;Activate();};
            Resize+=(s,e)=>{if(WindowState==FormWindowState.Minimized){Hide();tray.ShowBalloonTip(1200,"PC Copilot","Still running in the tray. Ctrl+Shift+Space opens Copilot.",ToolTipIcon.Info);}};
        }

        void SetupMonitoring()
        {
            try{cpuCounter=new PerformanceCounter("Processor","% Processor Time","_Total");cpuCounter.NextValue();}catch{}
            liveTimer.Interval=3000;liveTimer.Tick+=(s,e)=>Sample();liveTimer.Start();
            threatTimer.Interval=30000;threatTimer.Tick+=(s,e)=>ThreatPoll();threatTimer.Start();

            operationTimer.Interval=500;
            operationTimer.Tick+=(s,e)=>{
                if(operationWatch.IsRunning){
                    TimeSpan t=operationWatch.Elapsed;
                    progressElapsed.Text="Elapsed "+(t.TotalHours>=1?t.ToString(@"h\:mm\:ss"):t.ToString(@"m\:ss"));
                }
            };

            Sample();
        }
        void Sample()
        {
            try{if(cpuCounter!=null)cpuNow=Math.Max(0,Math.Min(100,cpuCounter.NextValue()));ramNow=RamPct();activeApp=ForegroundTitle();
                if(settings.LiveGuard&&cpuNow>=92&&DateTime.Now-lastHighCpu>TimeSpan.FromMinutes(10)){lastHighCpu=DateTime.Now;tray.ShowBalloonTip(3500,"PC Copilot: heavy sustained load","CPU is around "+cpuNow.ToString("0")+"%. Active app: "+activeApp,ToolTipIcon.Warning);}
            }catch{}
        }
        void ThreatPoll()
        {
            if(!settings.LiveGuard)return;
            try{
                string x=RunPS("$t=Get-MpThreatDetection|Sort InitialDetectionTime -Descending|Select -First 1 InitialDetectionTime;if($t){$t.InitialDetectionTime.ToString('o')}");
                DateTime d;if(DateTime.TryParse(x.Trim(),out d)&&d>lastThreat){lastThreat=d;tray.ShowBalloonTip(5000,"Defender detection","Windows Security recorded a threat detection. Open PC Copilot → Security → Threat history.",ToolTipIcon.Warning);}
            }catch{}
        }

        void ShowOverlay()
        {
            string app=ForegroundTitle();
            var f=new Form{Text="PC Copilot",Size=new Size(620,310),StartPosition=FormStartPosition.CenterScreen,TopMost=true,BackColor=Color.FromArgb(11,18,32),ForeColor=TextMain,FormBorderStyle=FormBorderStyle.FixedToolWindow};
            var h=new Label{Text="PC Copilot",Left=18,Top=16,AutoSize=true,ForeColor=TextMain,Font=new Font("Segoe UI Semibold",16,FontStyle.Bold)};
            var a=new Label{Text="Active: "+app,Left=20,Top=50,Width=560,Height=24,ForeColor=Muted};
            var q=new TextBox{Left=18,Top=84,Width=565,Height=36,BackColor=Color.FromArgb(6,12,23),ForeColor=TextMain,BorderStyle=BorderStyle.FixedSingle,Font=new Font("Segoe UI",10)};
            var answer=new RichTextBox{Left=18,Top=167,Width=565,Height=95,BackColor=Color.FromArgb(6,12,23),ForeColor=TextMain,ReadOnly=true,BorderStyle=BorderStyle.None};
            var ask=Btn("Ask",Indigo,110);ask.Left=18;ask.Top=128;
            var shot=Btn("Screenshot + Ask",Teal,165);shot.Left=138;shot.Top=128;
            var web=new CheckBox{Text="Current web",Checked=settings.UseWeb,Left=320,Top=137,AutoSize=true,ForeColor=TextMain};
            ask.Click+=async(s,e)=>{answer.Text="Thinking...";answer.Text=await AskAI("Active app/window: "+app+"\nQuestion: "+q.Text,false,false,web.Checked);};
            shot.Click+=async(s,e)=>{answer.Text="Capturing current screen and analyzing...";answer.Text=await AskAI("Active app/window: "+app+"\nQuestion: "+q.Text,true,false,web.Checked);};
            f.Controls.AddRange(new Control[]{h,a,q,ask,shot,web,answer});f.Show();
        }

        async Task Diagnose(string question,bool screenshot)
        {
            string ans=await AskAI(question,screenshot,true,settings.UseWeb);
            var f=new Form{Text="PC Copilot Advice",Size=new Size(760,520),StartPosition=FormStartPosition.CenterParent,BackColor=Bg,ForeColor=TextMain};
            var box=new RichTextBox{Dock=DockStyle.Fill,BackColor=Color.FromArgb(8,15,27),ForeColor=TextMain,ReadOnly=true,BorderStyle=BorderStyle.None,Font=new Font("Segoe UI",10),Text=ans};f.Controls.Add(box);f.Show();
        }

        async Task<string> AskAI(string question,bool screenshot,bool diagnostics,bool web)
        {
            if(string.IsNullOrWhiteSpace(question)) question="Tell me what is happening on this screen and what I should do next.";
            string key=!string.IsNullOrWhiteSpace(settings.ApiKey)?settings.ApiKey:Environment.GetEnvironmentVariable("OPENAI_API_KEY");
            if(string.IsNullOrWhiteSpace(key)) return "AI is not connected yet. Open Settings and add an OpenAI API key, or set OPENAI_API_KEY in Windows.";

            string diag=diagnostics?CreateDiagnostic(question):"";
            string memory=settings.Memory.Count==0?"No saved user preferences.":string.Join("\n",settings.Memory.Select(x=>"• "+x).ToArray());
            string prompt=
                "You are Ultimate PC Copilot, a concise Windows/game/study assistant.\n"+
                "Explain things in clean everyday English. If diagnosing Windows, distinguish evidence from guesses. "+
                "Never recommend disabling antivirus, anti-cheat, audio, networking, or essential security for performance. "+
                "For game questions, inspect the screenshot and give the immediate next action. "+
                "For schoolwork, help without pretending you can see content that is not present. "+
                "For repairs, explain consequences and advise whether the user should approve.\n\n"+
                "Saved preferences:\n"+memory+"\n\nQuestion:\n"+question+
                (diagnostics?"\n\nLocal diagnostic snapshot:\n"+diag:"");

            string imageData=null;
            if(screenshot){
                string path=CaptureScreen();
                imageData="data:image/png;base64,"+Convert.ToBase64String(File.ReadAllBytes(path));
            }
            return await OpenAIResponse(key,prompt,imageData,web);
        }

        async Task<string> OpenAIResponse(string key,string prompt,string imageData,bool web)
        {
            return await Task.Run(()=>{
                try{
                    var content=new List<Dictionary<string,object>>();
                    content.Add(new Dictionary<string,object>{{"type","input_text"},{"text",prompt}});
                    if(imageData!=null)content.Add(new Dictionary<string,object>{{"type","input_image"},{"image_url",imageData}});
                    var input=new object[]{new Dictionary<string,object>{{"role","user"},{"content",content}}};
                    var body=new Dictionary<string,object>{{"model",string.IsNullOrWhiteSpace(settings.Model)?"gpt-4.1-mini":settings.Model},{"input",input}};
                    if(web)body["tools"]=new object[]{new Dictionary<string,object>{{"type","web_search_preview"}}};
                    string json=new JavaScriptSerializer().Serialize(body);
                    var req=(HttpWebRequest)WebRequest.Create("https://api.openai.com/v1/responses");
                    req.Method="POST";req.ContentType="application/json";req.Headers["Authorization"]="Bearer "+key;
                    byte[] bytes=Encoding.UTF8.GetBytes(json);using(var st=req.GetRequestStream())st.Write(bytes,0,bytes.Length);
                    using(var resp=(HttpWebResponse)req.GetResponse())using(var sr=new StreamReader(resp.GetResponseStream())){
                        string raw=sr.ReadToEnd();var obj=new JavaScriptSerializer().DeserializeObject(raw) as Dictionary<string,object>;
                        if(obj!=null&&obj.ContainsKey("output")){
                            var arr=obj["output"] as ArrayList;
                            if(arr!=null)foreach(var it in arr){
                                var d=it as Dictionary<string,object>;if(d==null||!d.ContainsKey("content"))continue;
                                var ca=d["content"] as ArrayList;if(ca==null)continue;
                                foreach(var c in ca){var cd=c as Dictionary<string,object>;if(cd!=null&&cd.ContainsKey("text"))return cd["text"].ToString();}
                            }
                        }
                        return "AI returned a response, but this app could not parse the text. Raw response saved to Reports.";
                    }
                }catch(WebException ex){
                    try{using(var sr=new StreamReader(ex.Response.GetResponseStream()))return "AI request error:\n"+sr.ReadToEnd();}catch{return "AI request failed: "+ex.Message;}
                }catch(Exception ex){return "AI request failed: "+ex.Message;}
            });
        }

        string CaptureScreen()
        {
            var b=Screen.PrimaryScreen.Bounds;var bmp=new Bitmap(b.Width,b.Height);
            using(var g=Graphics.FromImage(bmp))g.CopyFromScreen(b.Location,Point.Empty,b.Size);
            string p=Path.Combine(dataDir,"last_screen.png");bmp.Save(p,ImageFormat.Png);bmp.Dispose();return p;
        }

        string CreateDiagnostic(string symptom)
        {
            var sb=new StringBuilder();sb.AppendLine("Symptom: "+symptom);sb.AppendLine("Time: "+DateTime.Now);
            sb.AppendLine("Active window: "+ForegroundTitle());sb.AppendLine("CPU now: "+cpuNow.ToString("0")+"%");sb.AppendLine("RAM used: "+RamPct()+"%");
            sb.AppendLine("Free C: "+SystemFreeGB().ToString("0.0")+" GB");sb.AppendLine("Defender real-time: "+DefenderRT());
            sb.AppendLine("\nTop memory processes:");
            foreach(var p in Process.GetProcesses().OrderByDescending(x=>{try{return x.WorkingSet64;}catch{return 0;}}).Take(15)){try{sb.AppendLine(p.ProcessName+" RAM "+(p.WorkingSet64/1024/1024)+" MB");}catch{}finally{p.Dispose();}}
            sb.AppendLine("\nRecent system errors:");
            sb.AppendLine(RunPS("Get-WinEvent -FilterHashtable @{LogName='System';Level=1,2;StartTime=(Get-Date).AddDays(-2)} -MaxEvents 25 | Select TimeCreated,ProviderName,Id,Message | Format-List | Out-String -Width 220"));
            sb.AppendLine("\nRecent app errors:");
            sb.AppendLine(RunPS("Get-WinEvent -FilterHashtable @{LogName='Application';Level=1,2;StartTime=(Get-Date).AddDays(-2)} -MaxEvents 20 | Select TimeCreated,ProviderName,Id,Message | Format-List | Out-String -Width 220"));
            sb.AppendLine("\nAuto services not running:");
            sb.AppendLine(RunPS("Get-CimInstance Win32_Service | ? {$_.StartMode -eq 'Auto' -and $_.State -ne 'Running'} | Select Name,DisplayName,State | Format-Table -AutoSize | Out-String"));
            sb.AppendLine("\nDefender exclusions:");
            sb.AppendLine(RunPS("Get-MpPreference | Select ExclusionPath,ExclusionProcess,ExclusionExtension | Format-List | Out-String"));
            string file=Path.Combine(reportsDir,"Diagnostic_"+DateTime.Now.ToString("yyyyMMdd_HHmmss")+".txt");File.WriteAllText(file,sb.ToString());return sb.ToString();
        }

        void DefenderUpdate(){RunPS("Update-MpSignature");}
        void DefenderQuick(){DefenderUpdate();RunPS("Start-MpScan -ScanType QuickScan");}
        void DefenderFull(){DefenderUpdate();RunPS("Start-MpScan -ScanType FullScan");}
        string DefenderRT(){string s=RunPS("(Get-MpComputerStatus).RealTimeProtectionEnabled");return s.Trim().Equals("True",StringComparison.OrdinalIgnoreCase)?"ON":"CHECK";}
        void ShowThreatHistory(){string s=RunPS("Get-MpThreatDetection | Sort InitialDetectionTime -Descending | Select -First 30 InitialDetectionTime,ThreatID,ActionSuccess,Resources | Format-List | Out-String -Width 220");string p=Path.Combine(reportsDir,"ThreatHistory_"+DateTime.Now.ToString("yyyyMMdd_HHmmss")+".txt");File.WriteAllText(p,s);Process.Start(p);}
        void SecurityAudit(){string s=RunPS("$p=Get-MpPreference;$c=Get-MpComputerStatus;'STATUS';$c|Select AntivirusEnabled,RealTimeProtectionEnabled,BehaviorMonitorEnabled,IsTamperProtected,AntivirusSignatureLastUpdated|fl;'EXCLUSIONS';$p|Select ExclusionPath,ExclusionProcess,ExclusionExtension|fl;'STARTUP';Get-CimInstance Win32_StartupCommand|ft -AutoSize;'TASKS';Get-ScheduledTask|? {$_.TaskPath -notlike '\\Microsoft\\*'}|Select TaskName,TaskPath,State|ft -AutoSize;'PROXY';netsh winhttp show proxy;'HOSTS';Get-Content $env:windir\\System32\\drivers\\etc\\hosts;'THREATS';Get-MpThreatDetection|Sort InitialDetectionTime -Descending|Select -First 20|fl|Out-String -Width 240");File.WriteAllText(Path.Combine(reportsDir,"SecurityAudit_"+DateTime.Now.ToString("yyyyMMdd_HHmmss")+".txt"),s);}
        void ResetUpdateCache(){RunPS("Stop-Service wuauserv -Force;Stop-Service bits -Force;Remove-Item $env:windir\\SoftwareDistribution\\Download\\* -Recurse -Force -ErrorAction SilentlyContinue;Start-Service bits;Start-Service wuauserv");}

        string CleanupAnalysis(){long t=DirSize(Environment.GetEnvironmentVariable("TEMP"))+DirSize(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Temp"));long b=BrowserCacheSize();long c=DirSize(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"CrashDumps"));return "Temporary files: "+Fmt(t)+"\nBrowser caches: "+Fmt(b)+"\nCrash dumps: "+Fmt(c)+"\n\nEstimated safe reclaimable: "+Fmt(t+b+c);}
        void SafeCleanup(){SafeDelete(Environment.GetEnvironmentVariable("TEMP"));SafeDelete(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Temp"));SafeDelete(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"CrashDumps"));CleanBrowserCaches();RunPS("ipconfig /flushdns");}
        long BrowserCacheSize(){string l=Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);return DirSize(Path.Combine(l,"Google","Chrome","User Data","Default","Cache"))+DirSize(Path.Combine(l,"Microsoft","Edge","User Data","Default","Cache"))+DirSize(Path.Combine(l,"BraveSoftware","Brave-Browser","User Data","Default","Cache"));}
        void CleanBrowserCaches(){string l=Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);SafeDelete(Path.Combine(l,"Google","Chrome","User Data","Default","Cache"));SafeDelete(Path.Combine(l,"Microsoft","Edge","User Data","Default","Cache"));SafeDelete(Path.Combine(l,"BraveSoftware","Brave-Browser","User Data","Default","Cache"));}
        long DirSize(string p){try{if(string.IsNullOrWhiteSpace(p)||!Directory.Exists(p))return 0;return Directory.EnumerateFiles(p,"*",SearchOption.AllDirectories).Sum(x=>{try{return new FileInfo(x).Length;}catch{return 0;}});}catch{return 0;}}
        void SafeDelete(string p){try{if(!Directory.Exists(p))return;foreach(var f in Directory.GetFiles(p)){try{File.Delete(f);}catch{}}foreach(var d in Directory.GetDirectories(p)){try{Directory.Delete(d,true);}catch{}}}catch{}}
        string Fmt(long b){if(b>=1073741824)return (b/1073741824.0).ToString("0.00")+" GB";if(b>=1048576)return (b/1048576.0).ToString("0.0")+" MB";return (b/1024.0).ToString("0")+" KB";}
        int RamPct(){try{var os=new ManagementObjectSearcher("select TotalVisibleMemorySize,FreePhysicalMemory from Win32_OperatingSystem").Get().Cast<ManagementObject>().First();double t=Convert.ToDouble(os["TotalVisibleMemorySize"]),f=Convert.ToDouble(os["FreePhysicalMemory"]);return (int)Math.Round((t-f)/t*100);}catch{return 0;}}
        double SystemFreeGB(){try{var d=new DriveInfo(Path.GetPathRoot(Environment.SystemDirectory));return d.AvailableFreeSpace/1073741824.0;}catch{return 0;}}
        string ForegroundTitle(){try{var sb=new StringBuilder(512);GetWindowText(GetForegroundWindow(),sb,sb.Capacity);return sb.Length>0?sb.ToString():"—";}catch{return "—";}}
        string RunPS(string cmd){try{var p=new Process();p.StartInfo=new ProcessStartInfo("powershell.exe","-NoProfile -ExecutionPolicy Bypass -Command \""+cmd.Replace("\"","\\\"")+"\""){UseShellExecute=false,RedirectStandardOutput=true,RedirectStandardError=true,CreateNoWindow=true};p.Start();string o=p.StandardOutput.ReadToEnd();string e=p.StandardError.ReadToEnd();p.WaitForExit();if(!string.IsNullOrWhiteSpace(e))WriteLog(e.Trim());return o;}catch(Exception ex){WriteLog(ex.Message);return "";}}
        object StartupData()
        {
            var rows=new List<StartupRow>();
            try{
                foreach(ManagementObject x in new ManagementObjectSearcher("select Name,Command,Location,User from Win32_StartupCommand").Get()){
                    string name=""+x["Name"];
                    string cmd=""+x["Command"];
                    string loc=""+x["Location"];
                    string pub=PublisherFromCommand(cmd);

                    string lower=(name+" "+cmd+" "+pub).ToLowerInvariant();
                    string impact="Low";
                    string rec="OPTIONAL";
                    string expl="This appears to be a normal application that starts with Windows. Disabling startup usually only means you will need to open the app yourself when you want it.";

                    if(lower.Contains("windows security")||lower.Contains("securityhealth")||lower.Contains("defender")){
                        impact="Low";rec="KEEP";expl="This is related to Windows Security. Leaving security-related startup components enabled is the safer choice.";
                    }else if(lower.Contains("realtek")||lower.Contains("nvidia")||lower.Contains("amd")||lower.Contains("intel")||lower.Contains("synaptics")||lower.Contains("touchpad")){
                        impact="Low";rec="KEEP";expl="This appears related to hardware, audio, graphics, or input-device software. Disabling it may remove tray controls, hotkeys, device features, or automatic driver utilities.";
                    }else if(lower.Contains("discord")){
                        impact="Medium";rec="OPTIONAL";expl="Discord is launching automatically. Disabling startup is generally safe; Discord will still work normally when you open it yourself.";
                    }else if(lower.Contains("steam")||lower.Contains("epic")||lower.Contains("battle.net")||lower.Contains("riot")||lower.Contains("launcher")){
                        impact="Medium";rec="OPTIONAL";expl="This looks like a game launcher. It does not usually need to run at every Windows startup. Disabling startup can reduce background RAM/CPU and the launcher will still work when opened manually.";
                    }else if(lower.Contains("teams")||lower.Contains("skype")||lower.Contains("zoom")){
                        impact="Medium";rec="OPTIONAL";expl="This communication app starts with Windows. Usually safe to disable if you do not need it ready immediately after sign-in.";
                    }else if(lower.Contains("onedrive")){
                        impact="Medium";rec="CAUTION";expl="OneDrive startup enables automatic file syncing. Disabling startup is safe for Windows, but your files will not automatically sync until OneDrive is opened.";
                    }else if(lower.Contains("adobe")||lower.Contains("acrobat")||lower.Contains("updater")||lower.Contains("update")){
                        impact="Low";rec="OPTIONAL";expl="This appears to be an updater/helper. Disabling startup is often safe, but automatic background update checks or quick-launch features may be delayed.";
                    }else if(lower.Contains("spotify")||lower.Contains("itunes")){
                        impact="Medium";rec="OPTIONAL";expl="This media app generally does not need to launch with Windows. Disabling startup is usually safe.";
                    }else if(lower.Contains("unknown")||string.IsNullOrWhiteSpace(pub)){
                        impact="Unknown";rec="REVIEW";expl="PC Copilot cannot confidently identify the publisher from this startup command. Do not disable it based only on the name; use AI double-check first.";
                    }

                    rows.Add(new StartupRow{
                        Name=name,Publisher=pub,Impact=impact,Recommendation=rec,
                        Explanation=expl,Command=cmd,Location=loc,User=""+x["User"]
                    });
                }
            }catch{}
            return rows;
        }

        string PublisherFromCommand(string cmd)
        {
            try{
                if(string.IsNullOrWhiteSpace(cmd))return "";
                string p=cmd.Trim();
                if(p.StartsWith("\"")){
                    int q=p.IndexOf('"',1);
                    if(q>1)p=p.Substring(1,q-1);
                }else{
                    int exe=p.IndexOf(".exe",StringComparison.OrdinalIgnoreCase);
                    if(exe>=0)p=p.Substring(0,exe+4);
                    else p=p.Split(' ')[0];
                }
                p=Environment.ExpandEnvironmentVariables(p);
                if(!File.Exists(p))return "";
                var vi=FileVersionInfo.GetVersionInfo(p);
                return vi.CompanyName??"";
            }catch{return "";}
        }
string FindLargeFiles(){var sb=new StringBuilder();string[] roots={Environment.GetFolderPath(Environment.SpecialFolder.UserProfile)+"\\Downloads",Environment.GetFolderPath(Environment.SpecialFolder.Desktop),Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),Environment.GetFolderPath(Environment.SpecialFolder.MyVideos)};foreach(var r in roots)try{if(Directory.Exists(r))foreach(var f in Directory.EnumerateFiles(r,"*",SearchOption.AllDirectories)){try{var fi=new FileInfo(f);if(fi.Length>500L*1024*1024)sb.AppendLine((fi.Length/1073741824.0).ToString("0.00")+" GB  "+f);}catch{}}}catch{}return sb.Length==0?"No files over 500 MB found in the scanned folders.":sb.ToString();}

        [STAThread]
        public static void Main(){Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);Application.Run(new MainForm());}
    }
}
